## Goal

A premium graduate-admissions portfolio for **Adaeze Joy Nzeakor** — digital media designer, creative strategist, and digital experience creator with a communications background — targeting the Master of Digital Media at TMU.

## Visual system

- Background `#0C0C0C`, white typography, yellow accent `#F5C542`, all as semantic tokens in `src/styles.css` (oklch)
- Kanit loaded via `<link>` in the root route head
- Glassmorphism panels (translucent surfaces, soft borders, backdrop blur), generous whitespace, Apple-level restraint
- Framer Motion for page transitions, scroll reveals, and hover micro-interactions
- Animated 3D-inspired hero background: layered CSS/canvas gradient orbs with parallax on pointer move (no WebGL dependency), reduced-motion respected
- Fully responsive, mobile-first (grid + `min-w-0` + `shrink-0` header rules)

## Pages

```text
/                      Hero, intro, "View My Work" CTA, featured work, skills strip
/work                  Index of the three case studies
/work/$slug            Full case study
/about                 Story, values, capabilities
/contact               Static contact details
```

Shared chrome (nav + footer) in `__root.tsx`, with page-transition wrapper around `<Outlet />`.

## Case studies (3)

Since project details weren't provided, I'll write three realistic, admissions-grade case studies grounded in your communications + strategy background. You can rename or replace the content later:

1. **Ọna** — a campus wayfinding and orientation experience for first-year international students
2. **Kindred** — brand and digital platform redesign for a community nonprofit
3. **Saidu B. Samaila & Co.** — real client project: the live website for a Nigerian chartered accounting firm (www.sbsamailaaccountants.com)

Each case study page follows the same structure: hero with large visual → meta bar (Timeline, Role, Skills, Tools, Outcomes) → **Challenge → Research → Design Process → Development → Final Solution → Reflection** → gallery grid with lightbox → prototype link CTA → next-project link.

Research sections include goals, user insights, and planning artifacts; Design Process includes information architecture diagrams, wireframe and sketch visuals, and iteration notes; Outcomes are shown as metric cards.

## Content & assets

- Written narrative copy for all sections in your voice — strategic, reflective, admissions-ready
- Generated imagery: hero visual, one cover per project, plus wireframe/IA/gallery visuals in a consistent dark-and-yellow art direction
- Contact page: email placeholder (tell me the address to use), LinkedIn → https://www.linkedin.com/in/nzeakorjoy, location Toronto, and a note about the TMU MDM application

## Technical notes

- TanStack Start file routes; case studies driven by a typed data module (`src/data/projects.ts`) so all three pages share one component
- `framer-motion` (Motion for React) added as a dependency
- Per-route `head()` metadata: unique title, description, og/twitter tags; JSON-LD `Person` schema on the home page; single H1 per page, semantic sections, alt text everywhere
- No backend needed (static contact info)

One open item: the email address to display on Contact — I'll use a placeholder until you give me the real one.