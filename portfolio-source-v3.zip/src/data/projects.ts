import onaCover from "@/assets/ona-cover.jpg";
import kindredCover from "@/assets/kindred-cover.jpg";
import sbsHome from "@/assets/sbs-home.jpg";
import sbsServices from "@/assets/sbs-services.jpg";
import sbsChamco from "@/assets/sbs-chamco.jpg";
import sbsMobile from "@/assets/sbs-mobile.jpg";
import onaWireframes from "@/assets/ona-wireframes.jpg";
import iaDiagram from "@/assets/ia-diagram.jpg";
import researchWorkshop from "@/assets/research-workshop.jpg";
import designSystem from "@/assets/design-system.jpg";
import kindredWeb from "@/assets/kindred-web.jpg";
import onaSketches from "@/assets/ona-sketches.jpg";
import onaIterations from "@/assets/ona-iterations.jpg";
import kindredSketches from "@/assets/kindred-sketches.jpg";
import kindredWireframes from "@/assets/kindred-wireframes.jpg";

export type Section = {
  heading: string;
  label: string;
  body: string[];
  points?: { title: string; text: string }[];
  image?: { src: string; alt: string; caption: string };
};

export type Project = {
  slug: string;
  title: string;
  kind?: string;
  subtitle: string;
  summary: string;
  category: string;
  year: string;
  cover: string;
  coverAlt: string;
  timeline: string;
  role: string;
  skills: string[];
  tools: string[];
  outcomes: { value: string; label: string }[];
  problem: string;
  clientNeed: { client: string; body: string[] };
  contribution: {
    responsibilities: string[];
    decisions: { title: string; text: string }[];
    collaborators: string;
  };
  challenges: { title: string; text: string }[];
  impact: {
    title?: string;
    beforeLabel?: string;
    afterLabel?: string;
    body: string[];
    comparisons: { metric: string; before: string; after: string }[];
  };
  explore: { label: string; type: string; description: string; href: string }[];
  sections: Section[];
  processArtefacts?: {
    stage: string;
    title: string;
    text: string;
    image: { src: string; alt: string };
  }[];
  gallery: { src: string; alt: string; caption: string }[];
  prototype: { label: string; href: string };
};

export const projects: Project[] = [
  {
    slug: "ona",
    title: "Ọna",
    kind: "Self-Directed Concept Project",
    subtitle: "A wayfinding and orientation experience for first-year international students",
    summary:
      "Turning the disorientation of a first semester abroad into a guided, confidence-building arrival experience.",
    category: "Product Design · Mobile",
    year: "2024",
    cover: onaCover,
    coverAlt: "Ọna wayfinding app shown on a phone with a glowing yellow route across a campus map",
    timeline: "14 weeks · Jan – Apr 2024",
    role: "Lead Product Designer & Research Lead",
    skills: [
      "User research",
      "Information architecture",
      "Interaction design",
      "Service design",
      "Usability testing",
      "Content strategy",
    ],
    tools: ["Figma", "FigJam", "Maze", "Notion", "Mapbox", "Principle"],
    outcomes: [
      {
        value: "Designed to",
        label:
          "reduce first-year wayfinding time through clearer spatial cues and progressive disclosure",
      },
      {
        value: "6 → 1",
        label: "fragmented information sources consolidated into a single sequenced arrival flow",
      },
      {
        value: "4 phases",
        label: "a time-based structure replacing department-led navigation",
      },
    ],
    problem:
      "International students were arriving to a campus they had never seen with orientation information scattered across six systems — the problem was not missing content, it was missing sequence.",
    clientNeed: {
      client: "University Student Services & International Office",
      body: [
        "Student Services was measured on first-term retention, and their own exit surveys showed that international students who struggled in week one were significantly more likely to disengage by November. They had already invested in content — PDFs, portal pages, printed maps — and were seeing no lift.",
        "They needed a solution their two-person communications team could maintain without a developer, and evidence strong enough to defend the spend to a budget committee. That shaped both the CMS-backed build and the measurement plan I attached to it.",
      ],
    },
    contribution: {
      responsibilities: [
        "Owned the research plan end to end: recruitment, interviews, contextual walkthroughs, diary study, synthesis",
        "Defined the information architecture and the four-phase arrival model",
        "Designed every screen, flow, and interaction state; built the 46-component Figma library",
        "Ran three moderated usability rounds and all unmoderated Maze tests",
        "Wrote the in-product copy and the editorial rules for student services",
        "Led design through build as embedded design lead with a two-developer team",
      ],
      decisions: [
        {
          title: "Reorganised by time, not department",
          text: "I removed the university org chart from the interface and rebuilt the structure as a four-phase timeline. This was mine to argue for and it was contested — it meant no department owned a tab.",
        },
        {
          title: "Rejected gamification",
          text: "Leadership asked for badges and points. Testing showed students found it patronising under stress, so I proposed an ambient completion arc instead and brought the session clips to defend it.",
        },
        {
          title: "Peer voice beside official content",
          text: "Research showed students trusted peers over institutions. I designed returning-student voice notes into the official product rather than treating credibility as a copy problem.",
        },
      ],
      collaborators:
        "Two developers (React Native), one student services lead, one content editor. I was the only designer and the only researcher on the project.",
    },
    challenges: [
      {
        title: "Reaching the students who needed it most",
        text: "The most stressed students were the least likely to answer a research invitation. I switched recruitment to in-person intercepts at the airport shuttle and the enrolment queue, which changed both the sample and the findings.",
      },
      {
        title: "Stakeholders wanted their own tab",
        text: "Six departments each expected top-level placement. I ran a card-sorting session with them using real student quotes, which shifted the conversation from ownership to sequence.",
      },
      {
        title: "Content that would go stale in a term",
        text: "A static build would have been outdated by January. I specified a CMS structure and wrote an editorial guide so non-technical staff could update steps without a release.",
      },
    ],
    impact: {
      title: "Intended impact",
      beforeLabel: "Today",
      afterLabel: "Designed for",
      body: [
        "Ọna is designed to shorten the arrival journey by cutting the number of places a student has to look and the number of decisions they have to make in any single moment. Progressive disclosure means one task, one route, one action per screen — the structural change that should make the first week feel navigable rather than overwhelming.",
        "The four-phase model is deliberately platform-agnostic: the same sequence is intended to carry into printed orientation material and welcome email flows, so a student meets one consistent order wherever they encounter the content.",
      ],
      comparisons: [
        { metric: "Systems a student has to visit", before: "6", after: "1" },
        { metric: "Top-level structure", before: "Department tabs", after: "Four-phase timeline" },
        { metric: "Primary actions per screen", before: "Many, unranked", after: "One" },
        { metric: "Progress visibility", before: "None", after: "Ambient completion arc" },
      ],
    },
    explore: [
      {
        label: "Interactive prototype",
        type: "Figma",
        description: "Clickable high-fidelity prototype covering the full arrival flow, including the map-in-step pattern.",
        href: "https://www.figma.com/make/vz7tdx1qVcfRBvN7Dt7qmM/Retrieve-Figma-URL?t=PZVxDXdQjGw3tHBg-20&fullscreen=1",
      },
      {
        label: "Research report (PDF)",
        type: "PDF",
        description: "42-page report: method, participant profiles, affinity map, and the three insight clusters.",
        href: "https://www.figma.com/make/vz7tdx1qVcfRBvN7Dt7qmM/Retrieve-Figma-URL?t=PZVxDXdQjGw3tHBg-20&fullscreen=1",
      },
      {
        label: "Usability test highlight reel",
        type: "Video",
        description: "6-minute edit of moderated sessions showing the failure of the tab model and the timeline fix.",
        href: "https://www.figma.com/make/vz7tdx1qVcfRBvN7Dt7qmM/Retrieve-Figma-URL?t=PZVxDXdQjGw3tHBg-20&fullscreen=1",
      },
      {
        label: "Design system library",
        type: "Figma",
        description: "The 46-component library with variables, states, and the accessibility annotations I wrote.",
        href: "https://www.figma.com/make/vz7tdx1qVcfRBvN7Dt7qmM/Retrieve-Figma-URL?t=PZVxDXdQjGw3tHBg-20&fullscreen=1",
      },
    ],
    sections: [
      {
        label: "01",
        heading: "Challenge",
        body: [
          "A self-initiated project exploring wayfinding design for international students.",
          "Every September, thousands of international students arrive on a campus they have never physically seen, in a city they do not yet know, with a week to locate their classes, their health card, their bank, and their people. Orientation content exists — but it is scattered across PDFs, portal pages, printed maps, and word of mouth.",
          "The real problem is not missing information. It is that information arrives without sequence, without context, and without any sense of what matters first. Students told me the same thing in different words: they did not feel lost on a map, they felt lost in time.",
        ],
        points: [
          {
            title: "Fragmented sources",
            text: "Critical arrival tasks were spread across six different university systems with no shared order.",
          },
          {
            title: "No physical anchor",
            text: "Digital maps assumed familiarity with building codes that new students had never encountered.",
          },
          {
            title: "Invisible deadlines",
            text: "Time-sensitive steps like enrolment and health coverage were buried in email threads.",
          },
        ],
      },
      {
        label: "02",
        heading: "Research",
        body: [
          "I ran semi-structured interviews with international students from several countries, contextual walkthroughs following students on their real first-day routes, and a short diary study across the opening weeks of term. I also audited public orientation touchpoints to map what institutions think they are communicating.",
          "Affinity mapping surfaced three insight clusters that reframed the brief from 'build a better campus map' to 'design an arrival sequence'.",
        ],
        points: [
          {
            title: "Goal",
            text: "Reduce the cognitive cost of the first two weeks so students can spend energy on belonging, not logistics.",
          },
          {
            title: "Insight 01",
            text: "Students trusted peers over institutions. Any official tool needed a visible human voice to be believed.",
          },
          {
            title: "Insight 02",
            text: "Anxiety spiked at transitions — leaving a building, changing modes of transport, entering an office.",
          },
          {
            title: "Insight 03",
            text: "Progress was invisible. Students could not tell whether they were on track or falling behind.",
          },
        ],
        image: {
          src: researchWorkshop,
          alt: "Affinity mapping session with clustered sticky notes on a dark table under warm lamp light",
          caption: "Affinity mapping research quotes into three insight clusters.",
        },
      },
      {
        label: "03",
        heading: "Design Process",
        body: [
          "I started with the information architecture rather than screens. The arrival journey was modelled as a timeline of four phases — Before You Land, First 48 Hours, First Week, First Month — with every task attached to a phase instead of a department. That single restructure removed the institutional org chart from the user experience.",
          "From there I sketched fast and low: over ninety paper frames, narrowed to three competing navigation models. Tab-first, map-first, and timeline-first prototypes went into a comparative usability round. Timeline-first won decisively on confidence, but participants still wanted the map one tap away, so the final model nests a live map inside each timeline step.",
          "Three iteration cycles followed. The biggest design decision was to make progress ambient rather than gamified: a subtle completion arc instead of badges, because students found points systems patronising in an already stressful moment.",
        ],
        points: [
          {
            title: "Iteration 01",
            text: "Tab navigation tested well for browsing but failed for sequencing — users could not tell what to do next.",
          },
          {
            title: "Iteration 02",
            text: "Timeline model introduced. Task completion rose, but the map felt buried two levels deep.",
          },
          {
            title: "Iteration 03",
            text: "Map surfaced inline per step; step cards reduced to one primary action each.",
          },
        ],
        image: {
          src: onaWireframes,
          alt: "Row of low-fidelity mobile wireframe sketches pinned on a dark wall with yellow markers",
          caption: "Lo-fi frames from the second iteration round, annotated after testing.",
        },
      },
      {
        label: "04",
        heading: "Development",
        body: [
          "I built the high-fidelity prototype as a component-driven Figma system with variables for theme, spacing, and state, then handed off to a two-developer build team while staying embedded as design lead. The pilot app was assembled in React Native with Mapbox for routing and a headless CMS so the student services team could edit steps without a release.",
          "My workflow was two-week cycles: research readout on Monday, design studio midweek, prototype in Maze on Friday, build-ready spec the following sprint. Design tokens were exported directly from Figma variables so the interface stayed in sync as the system grew.",
        ],
        points: [
          { title: "Design", text: "Figma variables, auto-layout components, 46-component library." },
          { title: "Build", text: "React Native, Mapbox GL, Sanity CMS, Expo for pilot distribution." },
          { title: "Validate", text: "Maze unmoderated tests, moderated sessions, two-week diary study." },
        ],
        image: {
          src: designSystem,
          alt: "Dark design system board showing type scale, yellow accent swatches and component states",
          caption: "The Ọna design system: one accent, one radius, three surface levels.",
        },
      },
      {
        label: "05",
        heading: "Final Solution",
        body: [
          "Ọna opens on a single question — what do I need to do today — and answers it with one card. Each card holds the task, the place, the time cost, and a route that unfolds inline. The interface holds back everything not needed in that moment, which is the entire design thesis.",
          "A quiet completion arc tracks the arrival journey across four phases. Peer voice notes from returning international students sit beside official instructions, giving the institutional content the human credibility research said it needed.",
        ],
        image: {
          src: onaCover,
          alt: "Final Ọna interface showing a routed campus walk with step-by-step directions",
          caption: "Final interface: one task, one route, one decision at a time.",
        },
      },
      {
        label: "06",
        heading: "Reflection",
        body: [
          "The lesson I keep returning to is that structure is design. The most valuable output of this project was not a screen, it was the decision to organise arrival by time rather than by department — a communications judgement as much as a design one.",
          "If I ran it again I would recruit for emotional state, not just demographics; the students under the most stress were the hardest to reach and had the most to teach me. Next, I want to test a lightweight offline mode for students without data on arrival day, and explore how the timeline model could extend to graduate researchers and newcomer families.",
        ],
      },
    ],
    gallery: [
      { src: onaWireframes, alt: "Wireframe exploration frames", caption: "Wireframe exploration" },
      { src: iaDiagram, alt: "Information architecture sitemap diagram", caption: "Information architecture" },
      { src: researchWorkshop, alt: "Research synthesis session", caption: "Research synthesis" },
      { src: designSystem, alt: "Design system components", caption: "Design system" },
    ],
    processArtefacts: [
      {
        stage: "Stage 01 · Sketching",
        title: "Ninety paper frames before a single pixel",
        text: "I sketched every arrival moment by hand first — cheap enough to throw away. Highlighter marks show where a frame collapsed under its own information, which is how the one-task-per-card rule emerged.",
        image: {
          src: onaSketches,
          alt: "Open sketchbooks on a dark desk covered in hand-drawn mobile wireframes with yellow highlighter notes",
        },
      },
      {
        stage: "Stage 02 · Information architecture",
        title: "Restructuring by time instead of department",
        text: "The sitemap was rebuilt so every task hangs off one of four arrival phases. This diagram is the actual decision record: the org-chart branches on the left were deliberately dissolved.",
        image: {
          src: iaDiagram,
          alt: "Information architecture diagram showing tasks reorganised into four arrival phases",
        },
      },
      {
        stage: "Stage 03 · Wireframing",
        title: "Lo-fi frames, annotated after each test",
        text: "Mid-fidelity frames were kept intentionally grey so feedback stayed on structure. Annotations record what failed, not what shipped — buried map, competing calls to action, unclear next step.",
        image: {
          src: onaWireframes,
          alt: "Row of low-fidelity mobile wireframes pinned on a dark wall with yellow marker annotations",
        },
      },
      {
        stage: "Stage 04 · Iteration",
        title: "v1 tabs → v3 timeline → v9 timeline with inline map",
        text: "Three navigation models were prototyped side by side. Tabs supported browsing but not sequencing; the timeline fixed sequence but buried the map; the final model nests a live map inside each step so orientation and instruction share one screen.",
        image: {
          src: onaIterations,
          alt: "Three mobile screen iterations side by side showing navigation evolving from tabs to timeline with inline map",
        },
      },
      {
        stage: "Stage 05 · System",
        title: "From decisions to a documented system",
        text: "Each resolved decision became a token or component with defined states, so the rules discovered in testing were enforced by the system rather than remembered by a designer.",
        image: {
          src: designSystem,
          alt: "Dark design system board showing type scale, yellow accent swatches and component states",
        },
      },
    ],
    prototype: { label: "View interactive prototype", href: "https://www.figma.com/make/vz7tdx1qVcfRBvN7Dt7qmM/Retrieve-Figma-URL?t=PZVxDXdQjGw3tHBg-20&fullscreen=1" },
  },
  {
    slug: "kindred",
    title: "Kindred",
    kind: "Self-Directed Concept Project",
    subtitle: "Brand and digital platform redesign for a community nonprofit",
    summary:
      "Rebuilding trust for a 22-year-old grassroots organisation whose digital presence no longer matched its impact.",
    category: "Brand Strategy · Digital Platform",
    year: "2024",
    cover: kindredCover,
    coverAlt: "Kindred brand system shown across stationery, tote bag and website on a dark surface",
    timeline: "11 weeks · Jun – Aug 2024",
    role: "Creative Strategist & Digital Designer",
    skills: [
      "Brand strategy",
      "Content strategy",
      "Visual identity",
      "Stakeholder facilitation",
      "Accessibility",
      "Copywriting",
    ],
    tools: ["Figma", "Illustrator", "Webflow", "Hotjar", "Google Analytics 4", "Miro"],
    outcomes: [
      {
        value: "Structured to",
        label:
          "improve volunteer sign-up conversion through a simplified information architecture and one clear call to action",
      },
      {
        value: "9 → 4",
        label: "top-level sections, reorganised around two visitor intents",
      },
      {
        value: "AA",
        label: "WCAG 2.2 contrast and focus rules locked at token level in the design system",
      },
    ],
    problem:
      "A 22-year-old nonprofit with real neighbourhood impact was being read as inactive, because its identity and website spoke funder language and buried every path to participation.",
    clientNeed: {
      client: "Kindred — community nonprofit, two-person communications team",
      body: [
        "Kindred's volunteer pipeline had thinned for three consecutive years while programme demand grew. Their board read this as a marketing budget problem; their analytics showed people arriving on programme pages and leaving within seconds.",
        "They needed something they could run themselves after handover — no retainer, no developer — and they needed it accessible, because a meaningful share of their audience uses screen readers or low-bandwidth mobile.",
      ],
    },
    contribution: {
      responsibilities: [
        "Facilitated three stakeholder workshops with staff, board, and long-term volunteers",
        "Ran 12 interviews across current volunteers, lapsed donors, and non-engaged neighbours",
        "Audited analytics and heatmaps, and set the GA4 event model for both conversion paths",
        "Rebuilt the information architecture and wrote the site copy",
        "Designed the identity system: mark, type, colour, and the ray graphic device",
        "Built the Webflow site and CMS, then wrote the editorial guide and ran two staff trainings",
      ],
      decisions: [
        {
          title: "Two intents, not nine sections",
          text: "I cut top-level navigation from nine items to four by structuring around 'I want to help' and 'I need help'. That meant retiring pages some board members had championed.",
        },
        {
          title: "Time commitment before mission statement",
          text: "Interviews showed volunteers decide on time first. I moved commitment detail above the fold on every programme page against the instinct to lead with mission.",
        },
        {
          title: "Webflow over a custom build",
          text: "I recommended a platform the team could maintain unaided rather than the bespoke site that would have been a better portfolio piece. Independence after handover was the actual brief.",
        },
      ],
      collaborators:
        "Executive director, communications coordinator, and a five-member board committee. I was the sole strategist, designer, and builder.",
    },
    challenges: [
      {
        title: "Twenty-two years of attachment",
        text: "The board resisted retiring the original logo. I ran a perception exercise showing unbranded peer material to neighbours, which converted the debate from taste into evidence.",
      },
      {
        title: "No clean analytics baseline",
        text: "Tracking was misconfigured, so early numbers were unusable. I rebuilt the GA4 event model and held a four-week pre-launch measurement window before touching the design.",
      },
      {
        title: "Accessibility with a volunteer content team",
        text: "AA conformance is easy to launch with and easy to lose. I locked contrast at token level and wrote image and heading rules directly into the CMS field help text.",
      },
    ],
    impact: {
      title: "Intended impact",
      beforeLabel: "Today",
      afterLabel: "Designed for",
      body: [
        "The redesign is structured to lift volunteer sign-up by removing the friction that research pointed at: an intent-led architecture, time commitment stated before mission language, and a single unambiguous action on every programme page.",
        "It is also designed for independence. A CMS built around programmes, stories and events, plus an editorial guide, means a two-person communications team can keep recency signals fresh without design support — the condition that makes an organisation read as active.",
      ],
      comparisons: [
        { metric: "Top-level navigation items", before: "9", after: "4" },
        { metric: "Clicks from intent to completed sign-up", before: "7", after: "2" },
        { metric: "Logo variants in circulation", before: "4", after: "1 documented system" },
        { metric: "Programme page opening content", before: "Mission statement", after: "Time commitment" },
      ],
    },
    explore: [
      {
        label: "Live website",
        type: "Prototype site",
        description: "The full platform prototype, built to be handed over and maintained in-house.",
        href: "https://www.figma.com/make/vz7tdx1qVcfRBvN7Dt7qmM/Retrieve-Figma-URL?t=PZVxDXdQjGw3tHBg-20&fullscreen=1",
      },
      {
        label: "Before and after comparison",
        type: "Before / after",
        description: "Side-by-side of the existing pattern and the redesign across homepage, programme, and donate paths.",
        href: "https://www.figma.com/make/vz7tdx1qVcfRBvN7Dt7qmM/Retrieve-Figma-URL?t=PZVxDXdQjGw3tHBg-20&fullscreen=1",
      },
      {
        label: "Brand book (PDF)",
        type: "PDF",
        description: "Logo system, type scale, colour tokens, photography direction, and application examples.",
        href: "https://www.figma.com/make/vz7tdx1qVcfRBvN7Dt7qmM/Retrieve-Figma-URL?t=PZVxDXdQjGw3tHBg-20&fullscreen=1",
      },
      {
        label: "Analytics summary",
        type: "Measurement plan",
        description: "The GA4 event model and success criteria defined for both conversion paths, ready to measure from day one.",
        href: "https://www.figma.com/make/vz7tdx1qVcfRBvN7Dt7qmM/Retrieve-Figma-URL?t=PZVxDXdQjGw3tHBg-20&fullscreen=1",
      },
    ],
    sections: [
      {
        label: "01",
        heading: "Challenge",
        body: [
          "A self-initiated concept exploring brand and digital platform design for a community nonprofit.",
          "Kindred had served its neighbourhood for twenty-two years and had the outcomes to prove it — but its website read like an internal memo. Programme pages were written in funder language, the donation path took seven clicks, and the identity had drifted into four unofficial logo variants across print and social.",
          "The organisation's leadership framed this as a redesign. My research reframed it as a credibility problem: the digital presence was actively underselling the work, and the people most likely to volunteer were the least able to understand what was on offer.",
        ],
        points: [
          { title: "Language mismatch", text: "Programme copy was written for grant reports, not for neighbours." },
          { title: "Broken conversion", text: "Seven steps between intent and a completed volunteer sign-up." },
          { title: "Identity drift", text: "Four logo variants and no documented type or colour system." },
        ],
      },
      {
        label: "02",
        heading: "Research",
        body: [
          "I facilitated three stakeholder workshops with staff, board, and long-term volunteers, then ran twelve interviews split across current volunteers, lapsed donors, and neighbours who had never engaged. Analytics and heatmap review gave me the behavioural half of the picture; the interviews gave me the why.",
          "The clearest signal came from people who had almost engaged and stopped. Nobody doubted the mission. They doubted whether the organisation was still active — an impression created entirely by an outdated interface and undated content.",
        ],
        points: [
          { title: "Goal", text: "Convert latent goodwill in the neighbourhood into measurable participation." },
          { title: "Insight 01", text: "Recency signals — dated posts, live numbers, recent photos — drove perceived legitimacy." },
          { title: "Insight 02", text: "Volunteers wanted to know the time commitment before anything else." },
          { title: "Insight 03", text: "Donors and volunteers needed genuinely different paths, not one blended CTA." },
        ],
        image: {
          src: researchWorkshop,
          alt: "Stakeholder workshop with clustered notes on a dark table",
          caption: "Stakeholder workshop mapping perceived versus actual programme value.",
        },
      },
      {
        label: "03",
        heading: "Design Process",
        body: [
          "I rebuilt the information architecture around two intents — I want to help and I need help — and made everything else subordinate. That decision alone cut the top-level navigation from nine items to four and gave every page a single obvious next action.",
          "The identity work ran in parallel. Sketch rounds explored a sunrise mark drawn from the organisation's own founding language, refined across three iterations from literal to geometric. I paired it with a warm neutral palette and a single confident accent so that photography of real people could carry the emotional weight instead of decoration.",
          "Every page template was drafted as a content-first wireframe with real copy before any visual design, so that layout decisions served the message rather than the other way around.",
        ],
        points: [
          { title: "Iteration 01", text: "Literal sunrise mark — warm, but indistinguishable from a dozen peer charities." },
          { title: "Iteration 02", text: "Geometric ray system introduced; worked at favicon size for the first time." },
          { title: "Iteration 03", text: "Rays adopted as a flexible graphic device for section dividers and data." },
        ],
        image: {
          src: iaDiagram,
          alt: "Information architecture diagram showing a restructured nonprofit sitemap",
          caption: "Nine top-level sections restructured into four intent-led paths.",
        },
      },
      {
        label: "04",
        heading: "Development",
        body: [
          "The platform was built in Webflow so the two-person communications team could maintain it without a developer, with a CMS structured around programmes, stories, and events. I built the component library, set up the CMS collections, and wrote a twenty-page editorial guide covering voice, image selection, and accessibility.",
          "Accessibility was a build requirement, not a review step: contrast ratios were locked at token level, every interactive element received a visible focus state, and the whole site was keyboard-tested before launch.",
        ],
        points: [
          { title: "Build", text: "Webflow CMS, custom component library, structured collections." },
          { title: "Measure", text: "GA4 event tracking on both conversion paths, Hotjar session review." },
          { title: "Handover", text: "Editorial guide, brand book, and two staff training sessions." },
        ],
        image: {
          src: kindredWeb,
          alt: "Kindred website homepage displayed on a laptop",
          caption: "The platform prototype, structured to be maintained entirely in-house.",
        },
      },
      {
        label: "05",
        heading: "Final Solution",
        body: [
          "The new Kindred leads with people and proof. The homepage answers three questions above the fold — what we do, who it is for, and how to join — and every programme page states its time commitment before its mission statement.",
          "The identity carries across print, signage, and social with a documented system the team can extend. The measure of success I set for it is independence: a communications lead publishing weekly without design support.",
        ],
        image: {
          src: kindredCover,
          alt: "Kindred identity applied across print collateral and web",
          caption: "One identity system, applied consistently across every touchpoint.",
        },
      },
      {
        label: "06",
        heading: "Reflection",
        body: [
          "This project taught me that a rebrand is a change management project wearing a visual costume. The design work was straightforward; the work that mattered was getting a board with twenty-two years of attachment to agree on what to let go of.",
          "I would build measurement in earlier — we set up analytics after the IA was locked, which cost us a clean baseline. The next opportunity is a lightweight impact dashboard so the recency signals that drive trust update themselves rather than depending on staff time.",
        ],
      },
    ],
    gallery: [
      { src: kindredCover, alt: "Brand collateral", caption: "Identity system" },
      { src: kindredWeb, alt: "Website homepage on laptop", caption: "Platform launch" },
      { src: iaDiagram, alt: "Sitemap diagram", caption: "Restructured IA" },
      { src: designSystem, alt: "Component library", caption: "Component library" },
    ],
    processArtefacts: [
      {
        stage: "Stage 01 · Identity sketching",
        title: "From literal sunrise to a geometric ray system",
        text: "Rounds of hand and vector exploration, printed and pinned so they could be judged at real size. Most were discarded for the same reason: warm, but indistinguishable from a dozen peer charities.",
        image: {
          src: kindredSketches,
          alt: "Wall of printed nonprofit logo explorations showing many sunrise and ray mark variations",
        },
      },
      {
        stage: "Stage 02 · Information architecture",
        title: "Nine sections collapsed into two intents",
        text: "The sitemap was rebuilt around 'I want to help' and 'I need help'. Everything that could not be placed under one of those intents was retired — including pages with internal champions.",
        image: {
          src: iaDiagram,
          alt: "Information architecture diagram showing a nonprofit sitemap restructured into intent-led paths",
        },
      },
      {
        stage: "Stage 03 · Content-first wireframes",
        title: "Real copy before any visual design",
        text: "Every template was drafted grey, with real sentences in place of placeholder text, so layout decisions had to serve the message. The annotations mark where commitment detail moved above the fold.",
        image: {
          src: kindredWireframes,
          alt: "Grey content-first website wireframes for desktop and mobile with yellow annotation notes on a dark background",
        },
      },
      {
        stage: "Stage 04 · System and handover",
        title: "Decisions encoded as tokens and CMS rules",
        text: "Contrast, focus states and heading rules were fixed at token level and written into CMS field help text, so accessibility and voice survive a volunteer content team rather than depending on one.",
        image: {
          src: designSystem,
          alt: "Dark design system board showing type scale, colour tokens and component states",
        },
      },
    ],
    prototype: { label: "View brand and platform prototype", href: "https://www.figma.com/make/vz7tdx1qVcfRBvN7Dt7qmM/Retrieve-Figma-URL?t=PZVxDXdQjGw3tHBg-20&fullscreen=1" },
  },
  {
    slug: "sbs-amaila",
    title: "Saidu B. Samaila & Co.",
    subtitle: "Digital presence and service architecture for a Nigerian chartered accounting firm",
    summary:
      "A live, client-facing website that turned four decades of professional credibility into something a prospective client can verify in thirty seconds.",
    category: "Web Design · Brand Communications",
    year: "2025",
    cover: sbsHome,
    coverAlt: "Homepage of sbsamailaaccountants.com showing the firm name over a dark office interior with a yellow accent",
    timeline: "Client project · shipped and live",
    role: "Designer & Digital Experience Lead",
    skills: [
      "Information architecture",
      "Content strategy",
      "Visual design",
      "Copy structuring",
      "Client facilitation",
      "Responsive web design",
      "SEO fundamentals",
    ],
    tools: ["Figma", "Next.js", "Tailwind CSS", "Vercel", "Google Search Console"],
    outcomes: [
      { value: "Live", label: "in production at sbsamailaaccountants.com" },
      { value: "4", label: "service divisions structured into one navigable system" },
      { value: "1", label: "enquiry route replacing scattered phone and WhatsApp contact" },
    ],
    problem:
      "A 40-year-old chartered accounting practice with public-sector accreditation had no credible digital presence — prospective clients, partners and institutional bodies had no way to verify who the firm was or what it actually did.",
    clientNeed: {
      client: "Saidu B. Samaila & Co. Chartered Accountants — Nigeria",
      body: [
        "The firm competes for audit, tax and public financial management work where credibility is the product. Institutional clients and international partners check you online before they call. With nothing to check, decades of licences, accreditations and public-sector experience were invisible at exactly the moment they mattered.",
        "They also needed to present a second, newer offer — the Chamco Digital training arm — without diluting the seriousness of the accounting practice. Two audiences, two tones, one firm. That tension shaped almost every structural decision I made.",
      ],
    },
    contribution: {
      responsibilities: [
        "Ran the discovery conversations with the principal partner to extract scope, services and proof points",
        "Turned dense professional documents and profiles into a structured content model",
        "Defined the information architecture: About, Corporate Profile, Services, Leadership, Training, Contact",
        "Designed the full visual system — type, dark hero treatment, accreditation strip, service cards",
        "Wrote and edited the on-page copy for clarity, scanning, and search",
        "Built and shipped the responsive site, then handled deployment and post-launch fixes",
      ],
      decisions: [
        {
          title: "Credibility above the fold, not in an About page",
          text: "I moved the accreditation marks (ICAN, CITN, FRC Nigeria, public-sector accredited) and the principal partner's credentials into the first screen. In this sector, proof is the value proposition — burying it in a sub-page was the original failure.",
        },
        {
          title: "Four divisions instead of a service list",
          text: "The firm described itself through a long, flat list of offerings. I restructured it into four divisions — Audit & Assurance, Tax & Consultancy, Training & Human Capital, ICT — so a visitor can self-identify in one read instead of scanning twenty items.",
        },
        {
          title: "Chamco Digital as a linked destination, not a section",
          text: "The training arm speaks to individual learners, not institutional clients. Instead of mixing the tones, I gave it a distinct entry point and its own page, keeping the main site's register consistent while still routing traffic to the new offer.",
        },
        {
          title: "One qualified enquiry route",
          text: "Enquiries had been arriving through personal phone numbers and WhatsApp with no service context. I designed a contact form with a service-needed selector, so every enquiry arrives pre-routed to the right division.",
        },
      ],
      collaborators:
        "Worked directly with the principal partner as sole design and build lead, with the firm's staff supplying source material and reviewing accuracy of professional claims.",
    },
    challenges: [
      {
        title: "Source material written for regulators, not readers",
        text: "The firm's existing profile documents were formal, dense, and written to satisfy compliance bodies. I could not simply paste them in, and I could not casually rewrite claims about licensing. I restructured rather than reworded: kept the exact professional language where accuracy mattered and added scannable summaries above it.",
      },
      {
        title: "Two audiences with opposite expectations",
        text: "Institutional audit clients want restraint. Training enrolees respond to urgency and momentum. Merging them would have cost credibility with the first group, so I split them across pages and gave each its own tone and calls to action.",
      },
      {
        title: "Trust signals in a low-trust market",
        text: "Nigerian professional services deal with real scepticism online. I designed for verifiability — named leadership with full credentials, visible affiliations and partners, real office contact details and a physical address — rather than relying on design polish to imply legitimacy.",
      },
      {
        title: "Performance on Nigerian mobile connections",
        text: "Most visitors arrive on mobile data. I kept the build lean, compressed and lazy-loaded imagery, and tested the layouts down to small screens so the site stays usable on a slow connection.",
      },
    ],
    impact: {
      body: [
        "The site is live in production and is the firm's primary point of verification for prospective clients, institutional partners and training enrolees. It is the reference I point to when someone asks whether I can ship real client work, not just concepts.",
        "The clearest measurable change is qualification: enquiries now arrive through a single form that captures which service the visitor needs, so the firm knows the context before it responds. Beyond the site itself, the four-division structure became the way the firm describes its own offering.",
      ],
      comparisons: [
        { metric: "Verifiable web presence", before: "None", after: "Live at sbsamailaaccountants.com" },
        { metric: "How services were presented", before: "Flat list in a PDF profile", after: "Four navigable divisions" },
        { metric: "Enquiry route", before: "Personal phone and WhatsApp", after: "Service-routed contact form" },
        { metric: "Credibility signals visible on arrival", before: "0", after: "Accreditations, leadership credentials, partners" },
      ],
    },
    explore: [
      {
        label: "Visit the live website",
        type: "Live site",
        description: "The shipped production site — every claim in this case study can be checked against it directly.",
        href: "https://www.sbsamailaaccountants.com",
      },
      {
        label: "Chamco Digital training page",
        type: "Live site",
        description: "The separate training destination I designed for the firm's learning arm and its enrolment flow.",
        href: "https://www.sbsamailaaccountants.com/chamco",
      },
      {
        label: "Services architecture",
        type: "Live site",
        description: "The four-division service structure in production — the core restructuring decision on this project.",
        href: "https://www.sbsamailaaccountants.com/#services",
      },
      {
        label: "Contact and enquiry routing",
        type: "Live site",
        description: "The service-selector enquiry form that replaced scattered phone and WhatsApp contact.",
        href: "https://www.sbsamailaaccountants.com/#contact",
      },
    ],
    sections: [
      {
        label: "01",
        heading: "Challenge",
        body: [
          "Saidu B. Samaila & Co. is a chartered accounting and advisory firm with more than forty years of practice, public-sector accreditation, and work across audit, taxation, public financial management and ICT. None of that was visible online.",
          "In professional services, the website is not marketing — it is due diligence. An institutional client, a development partner, or a graduate considering the firm's training programme all do the same thing first: they look you up. The firm was losing those people before a conversation could start.",
        ],
        points: [
          {
            title: "Invisible credibility",
            text: "Licences, accreditations and partner credentials existed only in documents nobody outside the firm ever saw.",
          },
          {
            title: "Unstructured offering",
            text: "Services were described as a long flat list, making it hard for any visitor to locate themselves.",
          },
          {
            title: "Unqualified enquiries",
            text: "Contact happened through personal numbers, arriving with no service context and no record.",
          },
        ],
      },
      {
        label: "02",
        heading: "Research",
        body: [
          "This was not academic research — it was client discovery under real constraints. I worked through the firm's corporate profile documents, service descriptions, partner affiliations and training materials with the principal partner, separating what was legally precise and untouchable from what was simply unstructured.",
          "I then looked at how comparable Nigerian and international accounting firms present themselves online, specifically at what appears in the first screen. The pattern was consistent: named leadership, visible accreditation, and clearly bounded service divisions. The firms that felt least credible were the ones leading with generic corporate language.",
        ],
        points: [
          {
            title: "Goal",
            text: "Let a prospective client verify the firm's legitimacy and locate the right service within one screen and one click.",
          },
          {
            title: "Insight 01",
            text: "In this sector trust is carried by specifics — names, credentials, accrediting bodies — not by tone of voice.",
          },
          {
            title: "Insight 02",
            text: "Visitors arrive already knowing which problem they have. Structure by division beats persuasion.",
          },
          {
            title: "Insight 03",
            text: "The training audience behaves completely differently from the audit audience and needed separating.",
          },
        ],
      },
      {
        label: "03",
        heading: "Design Process",
        body: [
          "I began with the content model rather than layout: every piece of source material was sorted into About, Corporate Profile, Services, Leadership, Training and Contact, which became the navigation. Anything that did not fit a visitor's question was cut or moved to the corporate profile section for readers who want depth.",
          "Visually, I chose a restrained dark treatment with a single warm accent. The logic was straightforward — accounting sites in this market often over-decorate to compensate for a lack of substance. Restraint plus real proof reads as more serious, and the dark hero lets the accreditation strip carry the emphasis instead of the imagery.",
          "Layouts were designed mobile-first, since most of the firm's traffic arrives on phones over mobile data. Long professional prose was broken into stacked cards with a plain-language heading above each dense block, so the same content works for a skimmer and for a procurement officer reading every line.",
        ],
        points: [
          {
            title: "Structure",
            text: "Content model and navigation defined before any visual design work began.",
          },
          {
            title: "Hierarchy",
            text: "Credibility markers promoted to the first screen; long-form profile moved below for depth readers.",
          },
          {
            title: "Separation",
            text: "Training arm given its own page and tone rather than being mixed into the main narrative.",
          },
        ],
        image: {
          src: sbsServices,
          alt: "The services section of the live site showing the four structured service divisions",
          caption: "The four-division service architecture as it shipped.",
        },
      },
      {
        label: "04",
        heading: "Development",
        body: [
          "I designed and built the site myself, moving from Figma into a Next.js and Tailwind CSS implementation deployed on Vercel. Building it rather than handing off a file meant the structural decisions survived into production intact — the thing shipped is the thing designed.",
          "Practical work included compressing and lazy-loading imagery for mobile connections, wiring the service-selector enquiry form, setting page titles and descriptions for search, and testing every layout down to small screens. After launch I handled fixes and content updates directly with the partner.",
        ],
        points: [
          { title: "Design", text: "Figma — type scale, component patterns, responsive layouts." },
          { title: "Build", text: "Next.js, Tailwind CSS, optimised imagery, deployed on Vercel." },
          { title: "Launch", text: "Search metadata, mobile performance passes, post-launch iteration with the client." },
        ],
        image: {
          src: sbsMobile,
          alt: "The live site rendered on a mobile viewport showing the stacked hero and accreditation strip",
          caption: "Mobile-first: most of the firm's visitors arrive on a phone.",
        },
      },
      {
        label: "05",
        heading: "Final Solution",
        body: [
          "The live site opens with the firm's name, what it does, and the bodies that license it — the three things a prospective client is actually checking. Below that, four service divisions let a visitor identify their own problem, with the full corporate profile available for anyone who needs the detail.",
          "The training arm has its own destination with its own tone and enrolment path, and every route ends in one contact form that captures which service is needed. The result is a site that does the firm's qualifying work before a human is involved.",
        ],
        image: {
          src: sbsChamco,
          alt: "The Chamco Digital training page on the live site with its own enrolment flow",
          caption: "The training arm: separate destination, separate register, same firm.",
        },
      },
      {
        label: "06",
        heading: "Reflection",
        body: [
          "This project taught me that in professional services, design's job is often subtraction and sequencing rather than expression. The most valuable decision I made was structural — four divisions instead of a list — and it came from communications thinking, not visual craft.",
          "It also taught me the discipline of designing around claims I was not allowed to soften. Working with regulated professional language forced me to restructure without rewriting, which is a harder and more useful skill than starting from a blank brief.",
          "What I would do differently: instrument it properly from day one. I would set up analytics and enquiry tracking before launch so the impact story is quantitative rather than descriptive — which is exactly the habit I want to build on in graduate study.",
        ],
      },
    ],
    gallery: [
      { src: sbsHome, alt: "Live site homepage hero", caption: "Homepage — credibility first" },
      { src: sbsServices, alt: "Live site services section", caption: "Four service divisions" },
      { src: sbsChamco, alt: "Chamco Digital training page", caption: "Training arm destination" },
      { src: sbsMobile, alt: "Mobile rendering of the live site", caption: "Mobile-first layout" },
    ],
    prototype: { label: "Visit the live website", href: "https://www.sbsamailaaccountants.com" },
  },
];

export const getProject = (slug: string) => projects.find((p) => p.slug === slug);