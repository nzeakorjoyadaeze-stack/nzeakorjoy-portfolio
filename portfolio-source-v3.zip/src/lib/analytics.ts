/**
 * Lightweight, provider-agnostic event tracking.
 *
 * Events are forwarded to whichever analytics client is present on the page
 * (Google Analytics gtag, PostHog, or a GTM dataLayer). If none is connected
 * yet, events are queued on `window.__lovableAnalyticsQueue` so nothing is lost
 * and so they can be inspected in the console during development.
 */

type EventProps = Record<string, string | number | boolean | undefined>;

declare global {
  interface Window {
    gtag?: (...args: unknown[]) => void;
    dataLayer?: unknown[];
    posthog?: { capture: (event: string, props?: EventProps) => void };
    __lovableAnalyticsQueue?: Array<{ event: string; props: EventProps; ts: number }>;
  }
}

export function trackEvent(event: string, props: EventProps = {}) {
  if (typeof window === "undefined") return;

  const payload: EventProps = { ...props };

  try {
    window.gtag?.("event", event, payload);
    window.posthog?.capture(event, payload);
    if (!window.gtag && Array.isArray(window.dataLayer)) {
      window.dataLayer.push({ event, ...payload });
    }
  } catch {
    // never let analytics break the UI
  }

  window.__lovableAnalyticsQueue = window.__lovableAnalyticsQueue ?? [];
  window.__lovableAnalyticsQueue.push({ event, props: payload, ts: Date.now() });
  if (window.__lovableAnalyticsQueue.length > 200) window.__lovableAnalyticsQueue.shift();

  if (import.meta.env.DEV) {
    console.debug("[analytics]", event, payload);
  }
}

export const analyticsEvents = {
  exploreOpen: "explore_viewer_open",
  exploreClose: "explore_viewer_close",
  mediaClick: "explore_media_click",
  compareUse: "explore_compare_use",
  galleryView: "explore_gallery_view",
} as const;
