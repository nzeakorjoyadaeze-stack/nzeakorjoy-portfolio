import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type CSSProperties } from "react";

const TITLE = "Nzeakor Joy Adaeze — Communications, Design & Digital Media";
const DESCRIPTION =
  "Portfolio of Nzeakor Joy Adaeze: a communications professional moving into design and digital media. Corporate website design, a tax filing portal redesign concept, and a human-in-the-loop AI communications concept.";

export const Route = createFileRoute("/v2/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
    ],
  }),
  component: V2Page,
});

const theme = {
  "--v2-bg": "#141A22",
  "--v2-surface": "#1A2129",
  "--v2-line": "rgba(237, 239, 234, 0.12)",
  "--v2-text": "#EDEFEA",
  "--v2-muted": "rgba(237, 239, 234, 0.64)",
  "--v2-gold": "#C79A46",
  "--v2-teal": "#4FA98C",
  "--v2-serif": "'Zilla Slab', Georgia, serif",
  "--v2-sans": "'Inter', ui-sans-serif, system-ui, sans-serif",
  "--v2-mono": "'IBM Plex Mono', ui-monospace, monospace",
} as CSSProperties;

const sections = [
  { id: "corporate-website", label: "01 / Corporate Website" },
  { id: "tax-portal", label: "02 / Tax Portal" },
  { id: "ai-assistant", label: "03 / AI Assistant" },
];

function Mono({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <span
      className={`font-[var(--v2-mono)] text-[0.7rem] tracking-[0.18em] uppercase ${className}`}
    >
      {children}
    </span>
  );
}

function Tag({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-full border border-[var(--v2-line)] px-3 py-1 font-[var(--v2-mono)] text-[0.68rem] tracking-[0.14em] text-[var(--v2-muted)] uppercase">
      {children}
    </span>
  );
}

function SectionHead({
  index,
  title,
  role,
  tools,
  live,
}: {
  index: string;
  title: string;
  role: string;
  tools?: string;
  live?: string;
}) {
  return (
    <header className="border-b border-[var(--v2-line)] pb-8">
      <Mono className="text-[var(--v2-gold)]">{index}</Mono>
      <h2 className="mt-4 max-w-3xl font-[var(--v2-serif)] text-3xl leading-[1.15] font-semibold sm:text-4xl lg:text-5xl">
        {title}
      </h2>
      <div className="mt-6 flex flex-wrap gap-2">
        <Tag>Role — {role}</Tag>
        {tools ? <Tag>Tools — {tools}</Tag> : null}
      </div>
      {live ? (
        <a
          href={live}
          target="_blank"
          rel="noreferrer noopener"
          className="mt-6 inline-flex items-center gap-2 font-[var(--v2-mono)] text-xs tracking-[0.14em] text-[var(--v2-gold)] uppercase underline decoration-[var(--v2-gold)]/40 underline-offset-4 hover:decoration-[var(--v2-gold)]"
        >
          View live site ↗
        </a>
      ) : null}
    </header>
  );
}

function Prose({ children }: { children: React.ReactNode }) {
  return (
    <div className="max-w-2xl space-y-5 text-[0.98rem] leading-relaxed text-[var(--v2-muted)]">
      {children}
    </div>
  );
}

function DecisionList({ items }: { items: { title: string; body: string }[] }) {
  return (
    <ol className="mt-10 grid gap-px overflow-hidden rounded-lg border border-[var(--v2-line)] bg-[var(--v2-line)] sm:grid-cols-2">
      {items.map((d, i) => (
        <li key={d.title} className="bg-[var(--v2-surface)] p-6">
          <Mono className="text-[var(--v2-gold)]">{`D${i + 1}`}</Mono>
          <h3 className="mt-3 font-[var(--v2-serif)] text-lg font-semibold">{d.title}</h3>
          <p className="mt-2 text-sm leading-relaxed text-[var(--v2-muted)]">{d.body}</p>
        </li>
      ))}
    </ol>
  );
}

function PlaceholderNote({ children }: { children: React.ReactNode }) {
  return (
    <p className="mt-10 rounded-lg border border-dashed border-[var(--v2-gold)]/50 bg-[var(--v2-gold)]/[0.06] p-5 font-[var(--v2-mono)] text-xs leading-relaxed tracking-wide text-[var(--v2-gold)]">
      {children}
    </p>
  );
}

/* ---------- Section 2 mockups ---------- */

const steps = [
  { n: "01", label: "Register", state: "done" },
  { n: "02", label: "File", state: "done" },
  { n: "03", label: "Pay", state: "current" },
  { n: "04", label: "Clearance", state: "todo" },
] as const;

function ProgressTracker() {
  return (
    <figure className="rounded-xl border border-[var(--v2-line)] bg-[var(--v2-surface)] p-6 sm:p-8">
      <Mono className="text-[var(--v2-muted)]">Filing status — 2025 annual return</Mono>
      <ol className="mt-6 grid gap-4 sm:grid-cols-4">
        {steps.map((s) => {
          const done = s.state === "done";
          const current = s.state === "current";
          return (
            <li key={s.label} className="min-w-0">
              <div
                className="h-1 w-full rounded-full"
                style={{
                  background: done
                    ? "var(--v2-teal)"
                    : current
                      ? "var(--v2-gold)"
                      : "rgba(237,239,234,0.14)",
                }}
              />
              <div className="mt-3 flex items-baseline gap-2">
                <Mono
                  className={
                    done
                      ? "text-[var(--v2-teal)]"
                      : current
                        ? "text-[var(--v2-gold)]"
                        : "text-[var(--v2-muted)]"
                  }
                >
                  {s.n}
                </Mono>
                <span className="text-sm font-medium">{s.label}</span>
              </div>
              <p className="mt-1 font-[var(--v2-mono)] text-[0.65rem] tracking-widest text-[var(--v2-muted)] uppercase">
                {done ? "Complete" : current ? "Action needed" : "Not started"}
              </p>
            </li>
          );
        })}
      </ol>
      <figcaption className="mt-6 border-t border-[var(--v2-line)] pt-4 text-sm text-[var(--v2-muted)]">
        Every screen answers one question first: where does my filing stand right now?
      </figcaption>
    </figure>
  );
}

function ReceiptCard() {
  const rows = [
    ["Reference", "TIN-2025-004871"],
    ["Assessment", "₦ 412,500.00"],
    ["Paid", "₦ 412,500.00"],
    ["Balance", "₦ 0.00"],
    ["Date", "2026-03-14 10:42"],
  ];
  return (
    <figure className="rounded-xl border border-[var(--v2-line)] bg-[var(--v2-bg)] p-6 sm:p-7">
      <div className="flex items-center justify-between gap-4 border-b border-dashed border-[var(--v2-line)] pb-4">
        <Mono className="text-[var(--v2-teal)]">Payment confirmed</Mono>
        <Mono className="text-[var(--v2-muted)]">Receipt</Mono>
      </div>
      <dl className="mt-4 space-y-3">
        {rows.map(([k, v]) => (
          <div key={k} className="flex items-baseline justify-between gap-4">
            <dt className="font-[var(--v2-mono)] text-[0.7rem] tracking-widest text-[var(--v2-muted)] uppercase">
              {k}
            </dt>
            <dd className="font-[var(--v2-mono)] text-sm tabular-nums">{v}</dd>
          </div>
        ))}
      </dl>
      <p className="mt-5 border-t border-dashed border-[var(--v2-line)] pt-4 text-xs leading-relaxed text-[var(--v2-muted)]">
        Downloadable, shareable, and permanent — the artefact a user can hand to an auditor or a bank.
      </p>
    </figure>
  );
}

/* ---------- Section 3 mockups ---------- */

function ChatThread() {
  const msgs = [
    { from: "client", text: "Good morning. Has my 2025 return been filed?" },
    {
      from: "ai",
      text: "Good morning, Mr. Bello. Your 2025 return was filed on 14 March. Your clearance certificate is pending assessment review — we expect it within 10 working days.",
    },
    { from: "client", text: "Thank you. And the levy payment?" },
  ];
  return (
    <figure className="rounded-xl border border-[var(--v2-line)] bg-[var(--v2-surface)] p-5 sm:p-6">
      <Mono className="text-[var(--v2-muted)]">WhatsApp Business — client thread</Mono>
      <div className="mt-5 space-y-3">
        {msgs.map((m, i) => (
          <div key={i} className={m.from === "client" ? "flex" : "flex justify-end"}>
            <div
              className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                m.from === "client"
                  ? "rounded-bl-sm bg-[var(--v2-bg)] text-[var(--v2-text)]"
                  : "rounded-br-sm border border-[var(--v2-teal)]/40 bg-[var(--v2-teal)]/10"
              }`}
            >
              {m.from === "ai" ? (
                <span className="mb-2 inline-flex items-center gap-1.5 rounded-full bg-[var(--v2-teal)]/20 px-2 py-0.5 font-[var(--v2-mono)] text-[0.6rem] tracking-[0.16em] text-[var(--v2-teal)] uppercase">
                  AI drafted · approved by staff
                </span>
              ) : null}
              <p>{m.text}</p>
            </div>
          </div>
        ))}
      </div>
    </figure>
  );
}

function ApprovalQueue() {
  const queue = [
    { client: "Bello, A.", intent: "Levy payment status", conf: "High" },
    { client: "Chamco Ltd.", intent: "Bootcamp cohort reminder", conf: "High" },
    { client: "Ministry of Works", intent: "Audit document request", conf: "Needs review" },
  ];
  return (
    <figure className="rounded-xl border border-[var(--v2-line)] bg-[var(--v2-bg)] p-5 sm:p-6">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <Mono className="text-[var(--v2-gold)]">Staff approval queue</Mono>
        <Mono className="text-[var(--v2-muted)]">3 drafts waiting</Mono>
      </div>
      <ul className="mt-5 space-y-3">
        {queue.map((q) => (
          <li
            key={q.client}
            className="grid gap-3 rounded-lg border border-[var(--v2-line)] p-4 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center"
          >
            <div className="min-w-0">
              <p className="truncate text-sm font-medium">{q.client}</p>
              <p className="mt-1 truncate font-[var(--v2-mono)] text-[0.7rem] tracking-wide text-[var(--v2-muted)]">
                {q.intent} · confidence: {q.conf}
              </p>
            </div>
            <div className="flex shrink-0 gap-2">
              <span className="rounded-md bg-[var(--v2-teal)]/15 px-3 py-1.5 font-[var(--v2-mono)] text-[0.65rem] tracking-widest text-[var(--v2-teal)] uppercase">
                Approve
              </span>
              <span className="rounded-md border border-[var(--v2-line)] px-3 py-1.5 font-[var(--v2-mono)] text-[0.65rem] tracking-widest text-[var(--v2-muted)] uppercase">
                Edit
              </span>
            </div>
          </li>
        ))}
      </ul>
      <p className="mt-5 text-xs leading-relaxed text-[var(--v2-muted)]">
        Nothing leaves the firm until a person presses approve. The queue is the product.
      </p>
    </figure>
  );
}

/* ---------- Page ---------- */

function V2Page() {
  const [active, setActive] = useState<string>("");

  useEffect(() => {
    const ids = ["hero", ...sections.map((s) => s.id)];
    const observer = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) setActive(e.target.id);
        }
      },
      { rootMargin: "-45% 0px -50% 0px" },
    );
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  return (
    <div
      style={theme}
      className="min-h-screen bg-[var(--v2-bg)] font-[var(--v2-sans)] text-[var(--v2-text)] antialiased"
    >
      <nav className="sticky top-0 z-50 border-b border-[var(--v2-line)] bg-[var(--v2-bg)]/85 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-5 py-4">
          <a
            href="#hero"
            className="shrink-0 font-[var(--v2-serif)] text-sm font-semibold tracking-tight sm:text-base"
          >
            Nzeakor Joy Adaeze
          </a>
          <ul className="flex min-w-0 items-center gap-4 overflow-x-auto">
            {sections.map((s) => (
              <li key={s.id} className="shrink-0">
                <a
                  href={`#${s.id}`}
                  className="font-[var(--v2-mono)] text-[0.65rem] tracking-[0.14em] uppercase transition-colors"
                  style={{ color: active === s.id ? "var(--v2-gold)" : "var(--v2-muted)" }}
                >
                  {s.label}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </nav>

      <main>
        <section id="hero" className="mx-auto max-w-5xl px-5 py-20 sm:py-28 lg:py-36">
          <Mono className="text-[var(--v2-gold)]">Portfolio · 2026</Mono>
          <h1 className="mt-6 font-[var(--v2-serif)] text-4xl leading-[1.05] font-semibold tracking-tight sm:text-6xl lg:text-7xl">
            Nzeakor Joy
            <br />
            Adaeze
          </h1>
          <p className="mt-7 max-w-2xl text-lg leading-relaxed text-[var(--v2-muted)] sm:text-xl">
            Communications professional moving into design and digital media. I start with the
            message and the audience, then design the structure, content, and interface that carry
            it.
          </p>
          <div className="mt-10 flex flex-wrap items-center gap-x-6 gap-y-3">
            <a
              href="mailto:nzeakorjoyadaeze@gmail.com"
              className="font-[var(--v2-mono)] text-xs tracking-[0.14em] text-[var(--v2-text)] uppercase underline decoration-[var(--v2-gold)]/50 underline-offset-4 hover:text-[var(--v2-gold)]"
            >
              nzeakorjoyadaeze@gmail.com
            </a>
            <a
              href="https://www.linkedin.com/in/nzeakorjoy"
              target="_blank"
              rel="noreferrer noopener"
              className="font-[var(--v2-mono)] text-xs tracking-[0.14em] text-[var(--v2-text)] uppercase underline decoration-[var(--v2-gold)]/50 underline-offset-4 hover:text-[var(--v2-gold)]"
            >
              LinkedIn ↗
            </a>
          </div>
        </section>

        {/* SECTION 1 */}
        <section
          id="corporate-website"
          className="mx-auto max-w-5xl scroll-mt-20 border-t border-[var(--v2-line)] px-5 py-20 sm:py-24"
        >
          <SectionHead
            index="01 / Client work"
            title="Corporate Website Design & Content Strategy"
            role="Visual Design & Content Strategy"
            tools="Figma, Adobe, Canva"
            live="https://www.sbsamailaaccountants.com"
          />
          <div className="mt-10 grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,0.85fr)]">
            <Prose>
              <p>
                I designed and wrote the content for a Nigerian chartered accountancy firm's website.
                The site had to serve two audiences that rarely want the same thing: institutional
                and government clients who need credibility signals before they will even call, and
                prospective students for the firm's AI training bootcamp who need to see something
                current, energetic, and clearly worth their time.
              </p>
              <p>
                <strong className="font-medium text-[var(--v2-text)]">
                  Information architecture first.
                </strong>{" "}
                Before any visual work, I mapped what each audience needed to find and in what order.
                That produced a structure where the firm's regulated practice areas and its digital
                training arm each have a clear entry path from the homepage, instead of competing for
                the same navigation slot.
              </p>
              <p>
                <strong className="font-medium text-[var(--v2-text)]">
                  Content strategy built on proof, not adjectives.
                </strong>{" "}
                I replaced generic service copy with specific proof points — named client
                engagements, sector experience, and professional licensing — because credibility for
                an institutional buyer comes from evidence, not tone of voice.
              </p>
              <p>
                <strong className="font-medium text-[var(--v2-text)]">
                  One visual system, two registers.
                </strong>{" "}
                A shared typographic scale, grid, and palette hold the whole site together, while the
                bootcamp pages use warmer imagery and shorter blocks so the same brand can speak to a
                21-year-old and a permanent secretary without feeling like two websites.
              </p>
              <p>
                <strong className="font-medium text-[var(--v2-text)]">
                  Conversion-focused structure.
                </strong>{" "}
                Every page resolves to a single next step — an enquiry for the practice, an
                expression of interest for the bootcamp — so the firm can tell which audience an
                incoming lead belongs to before anyone replies.
              </p>
            </Prose>
            <div className="space-y-4">
              <div className="rounded-xl border border-[var(--v2-line)] bg-[var(--v2-surface)] p-6">
                <Mono className="text-[var(--v2-muted)]">At a glance</Mono>
                <ul className="mt-5 space-y-4 text-sm">
                  {[
                    ["Client", "Chartered accountancy firm, Nigeria"],
                    ["Audiences", "Institutional / government · Bootcamp students"],
                    ["Deliverables", "IA, content strategy, copy, visual system"],
                    ["Status", "Shipped and live"],
                  ].map(([k, v]) => (
                    <li key={k}>
                      <p className="font-[var(--v2-mono)] text-[0.65rem] tracking-widest text-[var(--v2-muted)] uppercase">
                        {k}
                      </p>
                      <p className="mt-1 leading-relaxed">{v}</p>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
          <PlaceholderNote>
            ★ Placeholder — add screenshots here: (1) homepage above the fold, (2) services section,
            (3) mobile view. Replace this note once the images are in.
          </PlaceholderNote>
        </section>

        {/* SECTION 2 */}
        <section
          id="tax-portal"
          className="mx-auto max-w-5xl scroll-mt-20 border-t border-[var(--v2-line)] px-5 py-20 sm:py-24"
        >
          <SectionHead
            index="02 / Concept"
            title="A Tax Filing Portal That Tells You Where You Stand"
            role="UX/UI Redesign concept"
            tools="Figma"
          />
          <div className="mt-10">
            <Prose>
              <p>
                A redesign concept for a Nigerian government tax e-filing portal. The core problem is
                not that filing is hard — it is that users have no idea what stage their filing is
                at. People submit, hear nothing, and then call, queue, or re-file out of anxiety.
              </p>
              <p>
                The concept makes state the primary interface: a four-step tracker that is always
                visible, and a receipt the user can keep after every payment.
              </p>
            </Prose>
            <div className="mt-10 grid gap-5 lg:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)]">
              <ProgressTracker />
              <ReceiptCard />
            </div>
            <DecisionList
              items={[
                {
                  title: "Visible progress over ambiguity",
                  body: "Register → File → Pay → Clearance is shown on every screen with an explicit current step, so the portal answers 'what now?' without a phone call.",
                },
                {
                  title: "Receipts as a permanent record",
                  body: "Each payment produces a downloadable, shareable receipt card with a reference number — the artefact users actually need for banks, auditors, and tenders.",
                },
                {
                  title: "A ledger-inspired visual language",
                  body: "Monospace, tabular numerals and ruled rows borrow from accounting documents, so figures align and the interface reads as authoritative rather than decorative.",
                },
                {
                  title: "Plain-language field labels",
                  body: "Statutory jargon is replaced with the question the user is actually answering, with the legal term kept as secondary helper text.",
                },
              ]}
            />
          </div>
        </section>

        {/* SECTION 3 */}
        <section
          id="ai-assistant"
          className="mx-auto max-w-5xl scroll-mt-20 border-t border-[var(--v2-line)] px-5 py-20 sm:py-24"
        >
          <SectionHead
            index="03 / Concept"
            title="An AI Assistant That Drafts. A Human Still Sends."
            role="Product concept"
            tools="Figma"
          />
          <div className="mt-10">
            <Prose>
              <p>
                A concept for an AI-assisted client communications tool for an accounting firm. It
                drafts filing reminders and answers to routine client questions — deadlines,
                document requests, payment status — but nothing is ever sent automatically. A staff
                member reviews, edits, and approves every message.
              </p>
              <p>
                In a regulated practice, speed is worthless if accuracy is uncertain. So the design
                puts the approval step, not the generation step, at the centre of the product.
              </p>
            </Prose>
            <div className="mt-10 grid gap-5 lg:grid-cols-2">
              <ChatThread />
              <ApprovalQueue />
            </div>
            <DecisionList
              items={[
                {
                  title: "Human-in-the-loop by design",
                  body: "The AI can only produce a draft. Sending is a deliberate human action, which keeps professional liability where it legally belongs — with the firm.",
                },
                {
                  title: "Meet clients on WhatsApp",
                  body: "Clients already message the firm on WhatsApp. Rather than asking them to adopt a new app, the assistant works inside the channel they use daily.",
                },
                {
                  title: "Mark AI-authored content visually",
                  body: "Drafted messages carry a persistent label and a distinct accent colour, so both staff and clients can tell what was machine-written and what a person approved.",
                },
                {
                  title: "Grounded in a real programme",
                  body: "The firm already runs an AI training bootcamp, so the concept extends capability it is genuinely building rather than importing a trend from outside.",
                },
              ]}
            />
          </div>
        </section>
      </main>

      <footer className="border-t border-[var(--v2-line)] px-5 py-12">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-4">
          <p className="font-[var(--v2-mono)] text-[0.68rem] tracking-[0.14em] text-[var(--v2-muted)] uppercase">
            © {new Date().getFullYear()} Nzeakor Joy Adaeze
          </p>
          <p className="font-[var(--v2-mono)] text-[0.68rem] tracking-[0.14em] text-[var(--v2-muted)] uppercase">
            Portfolio built for TMU Master of Digital Media application
          </p>
        </div>
      </footer>
    </div>
  );
}
