import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Reveal } from "@/components/site/Reveal";
import { ExploreViewer } from "@/components/site/ExploreViewer";
import { getProject, projects, type Project } from "@/data/projects";

export const Route = createFileRoute("/work/$slug")({
  loader: ({ params }) => {
    const project = getProject(params.slug);
    if (!project) throw notFound();
    return { project };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Case study unavailable" }, { name: "robots", content: "noindex" }],
      };
    }
    const title = `${loaderData.project.title} — Case Study by Adaeze Joy Nzeakor`;
    return {
      meta: [
        { title },
        { name: "description", content: loaderData.project.summary },
        { property: "og:title", content: title },
        { property: "og:description", content: loaderData.project.summary },
      ],
    };
  },
  notFoundComponent: CaseStudyNotFound,
  component: CaseStudy,
});

function CaseStudyNotFound() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-48 text-center sm:px-6">
      <h1 className="text-4xl font-extralight">Case study not found</h1>
      <p className="mt-4 text-muted-foreground">This project doesn't exist or has been renamed.</p>
      <Link to="/work" className="mt-8 inline-block rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground">
        Back to work
      </Link>
    </div>
  );
}

function CaseStudy() {
  const { project } = Route.useLoaderData() as { project: Project };
  const index = projects.findIndex((p) => p.slug === project.slug);
  const next = projects[(index + 1) % projects.length];

  return (
    <article className="pb-28 pt-36 lg:pt-44">
      {/* Hero */}
      <header className="px-4 sm:px-6">
        <div className="mx-auto max-w-6xl">
          <Reveal>
            <Link to="/work" className="text-xs font-light tracking-widest text-muted-foreground uppercase transition-colors hover:text-primary">
              ← All work
            </Link>
            <p className="mt-8 text-xs font-light tracking-widest text-primary uppercase">
              {project.category} · {project.year}
            </p>
            {project.kind && (
              <p className="mt-3 inline-flex items-center gap-2 rounded-full border border-border px-3 py-1 text-[0.7rem] font-light tracking-widest text-muted-foreground uppercase">
                <span aria-hidden="true" className="size-1 rounded-full bg-primary" />
                {project.kind}
              </p>
            )}
            <h1 className="text-balance-tight mt-5 text-5xl font-extralight leading-[1.02] sm:text-7xl">
              {project.title}
            </h1>
            <p className="mt-6 max-w-3xl text-xl font-light leading-relaxed text-muted-foreground sm:text-2xl">
              {project.subtitle}
            </p>
            <p className="mt-8 max-w-3xl border-l-2 border-primary/60 pl-5 text-base font-light leading-relaxed text-foreground/90">
              <span className="block text-xs font-light tracking-widest text-primary uppercase">
                The problem
              </span>
              <span className="mt-2 block">{project.problem}</span>
            </p>
          </Reveal>

          <Reveal delay={0.1} className="mt-14">
            <div className="overflow-hidden rounded-3xl border border-border">
              <img
                src={project.cover}
                alt={project.coverAlt}
                width={1600}
                height={1000}
                className="w-full object-cover"
              />
            </div>
          </Reveal>
        </div>
      </header>

      {/* Meta bar */}
      <section className="mt-14 px-4 sm:px-6" aria-label="Project details">
        <div className="glass mx-auto grid max-w-6xl gap-8 rounded-3xl p-8 sm:grid-cols-2 lg:grid-cols-4 sm:p-10">
          <Meta title="Timeline" items={[project.timeline]} />
          <Meta title="My role" items={[project.role]} />
          <Meta title="Skills used" items={project.skills} />
          <Meta title="Tools used" items={project.tools} />
        </div>
      </section>

      {/* Outcomes */}
      <section className="mt-8 px-4 sm:px-6" aria-labelledby="outcomes-heading">
        <div className="mx-auto max-w-6xl">
          <h2 id="outcomes-heading" className="sr-only">
            Outcomes
          </h2>
          <div className="grid gap-4 sm:grid-cols-3">
            {project.outcomes.map((o, i) => (
              <Reveal key={o.label} delay={i * 0.06}>
                <div className="glass h-full rounded-2xl p-7 transition-colors duration-300 hover:border-primary/40">
                  <p className="text-4xl font-light text-primary">{o.value}</p>
                  <p className="mt-2 text-sm font-light leading-relaxed text-muted-foreground">{o.label}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Why the client needed this */}
      <section className="mt-24 px-4 sm:px-6 lg:mt-32" aria-labelledby="need-heading">
        <div className="mx-auto grid max-w-6xl gap-10 lg:grid-cols-[minmax(0,10rem)_minmax(0,1fr)]">
          <Reveal>
            <p className="text-sm font-light tracking-widest text-primary uppercase">Why</p>
            <h2 id="need-heading" className="mt-2 text-3xl font-light tracking-tight">
              Why the client needed this
            </h2>
          </Reveal>
          <div className="min-w-0">
            <Reveal delay={0.05}>
              <p className="text-xs font-light tracking-widest text-muted-foreground uppercase">
                Client · {project.clientNeed.client}
              </p>
              <div className="mt-5 max-w-3xl space-y-6">
                {project.clientNeed.body.map((p) => (
                  <p key={p.slice(0, 24)} className="text-lg font-light leading-relaxed text-muted-foreground">
                    {p}
                  </p>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* My contribution */}
      <section className="mt-24 px-4 sm:px-6 lg:mt-32" aria-labelledby="contribution-heading">
        <div className="mx-auto grid max-w-6xl gap-10 lg:grid-cols-[minmax(0,10rem)_minmax(0,1fr)]">
          <Reveal>
            <p className="text-sm font-light tracking-widest text-primary uppercase">Role</p>
            <h2 id="contribution-heading" className="mt-2 text-3xl font-light tracking-tight">
              What I personally did
            </h2>
          </Reveal>
          <div className="min-w-0">
            <Reveal delay={0.05}>
              <div className="glass rounded-2xl p-7">
                <h3 className="text-xs font-light tracking-widest text-primary uppercase">
                  My responsibilities
                </h3>
                <ul className="mt-4 space-y-3">
                  {project.contribution.responsibilities.map((r) => (
                    <li key={r} className="flex gap-3 text-base font-light leading-relaxed text-muted-foreground">
                      <span aria-hidden="true" className="mt-2 h-1 w-1 shrink-0 rounded-full bg-primary" />
                      {r}
                    </li>
                  ))}
                </ul>
                <p className="mt-6 border-t border-border pt-5 text-sm font-light leading-relaxed text-muted-foreground">
                  <span className="text-primary">Team · </span>
                  {project.contribution.collaborators}
                </p>
              </div>
            </Reveal>

            <h3 className="mt-10 text-xs font-light tracking-widest text-primary uppercase">
              Decisions I owned
            </h3>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              {project.contribution.decisions.map((d, i) => (
                <Reveal key={d.title} delay={i * 0.05}>
                  <div className="glass h-full rounded-2xl p-6 transition-colors duration-300 hover:border-primary/40">
                    <h4 className="text-base font-medium text-primary">{d.title}</h4>
                    <p className="mt-2 text-sm font-light leading-relaxed text-muted-foreground">{d.text}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Sections */}
      <div className="mt-24 space-y-24 px-4 sm:px-6 lg:mt-32 lg:space-y-32">
        {project.sections.map((s) => (
          <section key={s.heading} className="mx-auto max-w-6xl" aria-labelledby={`s-${s.label}`}>
            <div className="grid gap-10 lg:grid-cols-[minmax(0,10rem)_minmax(0,1fr)]">
              <Reveal>
                <p className="text-sm font-light tracking-widest text-primary uppercase">{s.label}</p>
                <h2 id={`s-${s.label}`} className="mt-2 text-3xl font-light tracking-tight lg:sticky lg:top-32">
                  {s.heading}
                </h2>
              </Reveal>
              <div className="min-w-0">
                <Reveal delay={0.05}>
                  <div className="max-w-3xl space-y-6">
                    {s.body.map((p) => (
                      <p key={p.slice(0, 24)} className="text-lg font-light leading-relaxed text-muted-foreground">
                        {p}
                      </p>
                    ))}
                  </div>
                </Reveal>

                {s.points && (
                  <div className="mt-10 grid gap-4 sm:grid-cols-2">
                    {s.points.map((pt, i) => (
                      <Reveal key={pt.title} delay={i * 0.05}>
                        <div className="glass h-full rounded-2xl p-6 transition-colors duration-300 hover:border-primary/40">
                          <h3 className="text-base font-medium text-primary">{pt.title}</h3>
                          <p className="mt-2 text-sm font-light leading-relaxed text-muted-foreground">
                            {pt.text}
                          </p>
                        </div>
                      </Reveal>
                    ))}
                  </div>
                )}

                {s.image && (
                  <Reveal delay={0.08}>
                    <figure className="mt-10">
                      <div className="overflow-hidden rounded-2xl border border-border">
                        <img
                          src={s.image.src}
                          alt={s.image.alt}
                          loading="lazy"
                          width={1400}
                          height={900}
                          className="w-full object-cover transition-transform duration-[900ms] ease-out hover:scale-[1.03]"
                        />
                      </div>
                      <figcaption className="mt-3 text-xs font-light text-muted-foreground">
                        {s.image.caption}
                      </figcaption>
                    </figure>
                  </Reveal>
                )}
              </div>
            </div>
          </section>
        ))}
      </div>

      {/* Challenges overcome */}
      {project.processArtefacts && (
        <section className="mt-24 px-4 sm:px-6 lg:mt-32" aria-labelledby="process-doc-heading">
          <div className="mx-auto grid max-w-6xl gap-10 lg:grid-cols-[minmax(0,10rem)_minmax(0,1fr)]">
            <Reveal>
              <p className="text-sm font-light tracking-widest text-primary uppercase">Process</p>
              <h2
                id="process-doc-heading"
                className="mt-2 text-3xl font-light tracking-tight lg:sticky lg:top-32"
              >
                Process documentation
              </h2>
            </Reveal>
            <div className="min-w-0 space-y-6">
              <Reveal delay={0.05}>
                <p className="max-w-3xl text-lg font-light leading-relaxed text-muted-foreground">
                  The artefacts behind the final screens — sketches, architecture, wireframes, and the
                  iterations that were rejected along the way, with the reasoning attached to each.
                </p>
              </Reveal>
              {project.processArtefacts.map((a, i) => (
                <Reveal key={a.title} delay={0.05 + i * 0.04}>
                  <figure className="glass overflow-hidden rounded-2xl transition-colors duration-300 hover:border-primary/40">
                    <img
                      src={a.image.src}
                      alt={a.image.alt}
                      loading="lazy"
                      width={1400}
                      height={900}
                      className="aspect-16/10 w-full object-cover"
                    />
                    <figcaption className="p-6 sm:p-7">
                      <p className="text-xs font-light tracking-widest text-primary uppercase">
                        {a.stage}
                      </p>
                      <h3 className="mt-3 text-lg font-medium">{a.title}</h3>
                      <p className="mt-2 text-sm font-light leading-relaxed text-muted-foreground">
                        {a.text}
                      </p>
                    </figcaption>
                  </figure>
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      <section className="mt-24 px-4 sm:px-6 lg:mt-32" aria-labelledby="challenges-heading">
        <div className="mx-auto grid max-w-6xl gap-10 lg:grid-cols-[minmax(0,10rem)_minmax(0,1fr)]">
          <Reveal>
            <p className="text-sm font-light tracking-widest text-primary uppercase">07</p>
            <h2 id="challenges-heading" className="mt-2 text-3xl font-light tracking-tight">
              Challenges I overcame
            </h2>
          </Reveal>
          <div className="grid min-w-0 gap-4 sm:grid-cols-2">
            {project.challenges.map((c, i) => (
              <Reveal key={c.title} delay={i * 0.05}>
                <div className="glass h-full rounded-2xl p-6 transition-colors duration-300 hover:border-primary/40">
                  <h3 className="text-base font-medium text-primary">{c.title}</h3>
                  <p className="mt-2 text-sm font-light leading-relaxed text-muted-foreground">{c.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Impact */}
      <section className="mt-24 px-4 sm:px-6 lg:mt-32" aria-labelledby="impact-heading">
        <div className="mx-auto grid max-w-6xl gap-10 lg:grid-cols-[minmax(0,10rem)_minmax(0,1fr)]">
          <Reveal>
            <p className="text-sm font-light tracking-widest text-primary uppercase">08</p>
            <h2 id="impact-heading" className="mt-2 text-3xl font-light tracking-tight">
              {project.impact.title ?? "Impact"}
            </h2>
          </Reveal>
          <div className="min-w-0">
            <Reveal delay={0.05}>
              <div className="max-w-3xl space-y-6">
                {project.impact.body.map((p) => (
                  <p key={p.slice(0, 24)} className="text-lg font-light leading-relaxed text-muted-foreground">
                    {p}
                  </p>
                ))}
              </div>
            </Reveal>
            <Reveal delay={0.08}>
              <div className="glass mt-10 overflow-hidden rounded-2xl">
                <table className="w-full text-left">
                  <caption className="sr-only">Before and after comparison</caption>
                  <thead>
                    <tr className="border-b border-border">
                      <th scope="col" className="px-6 py-4 text-xs font-light tracking-widest text-muted-foreground uppercase">
                        Measure
                      </th>
                      <th scope="col" className="px-6 py-4 text-xs font-light tracking-widest text-muted-foreground uppercase">
                        {project.impact.beforeLabel ?? "Before"}
                      </th>
                      <th scope="col" className="px-6 py-4 text-xs font-light tracking-widest text-primary uppercase">
                        {project.impact.afterLabel ?? "After"}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {project.impact.comparisons.map((c) => (
                      <tr key={c.metric} className="border-b border-border last:border-0">
                        <th scope="row" className="px-6 py-5 text-sm font-light text-muted-foreground">
                          {c.metric}
                        </th>
                        <td className="px-6 py-5 text-base font-light text-muted-foreground">{c.before}</td>
                        <td className="px-6 py-5 text-base font-medium text-primary">{c.after}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section className="mt-28 px-4 sm:px-6" aria-labelledby="gallery-heading">
        <div className="mx-auto max-w-6xl">
          <Reveal>
            <h2 id="gallery-heading" className="text-3xl font-extralight">
              Gallery
            </h2>
          </Reveal>
          <div className="mt-10 grid gap-4 sm:grid-cols-2">
            {project.gallery.map((g, i) => (
              <Reveal key={g.caption} delay={i * 0.05}>
                <figure className="group overflow-hidden rounded-2xl border border-border">
                  <img
                    src={g.src}
                    alt={g.alt}
                    loading="lazy"
                    width={1400}
                    height={900}
                    className="aspect-16/10 w-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-105"
                  />
                  <figcaption className="px-5 py-4 text-xs font-light tracking-widest text-muted-foreground uppercase">
                    {g.caption}
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Explore the work + next */}
      <section className="mt-20 px-4 sm:px-6">
        <div className="mx-auto max-w-6xl">
          <Reveal>
            <h2 className="text-3xl font-extralight">Explore the work</h2>
            <p className="mt-3 max-w-xl text-sm font-light text-muted-foreground">
              Open the artefacts directly — prototype, live site, documents, video, and before/after
              comparisons behind {project.title}. Each opens in an in-page viewer.
            </p>
          </Reveal>
          <ExploreViewer project={project} />

          <Reveal delay={0.06}>
            <Link
              to="/work/$slug"
              params={{ slug: next.slug }}
              className="group mt-6 flex items-center justify-between gap-6 rounded-3xl border border-border px-8 py-10 transition-colors duration-300 hover:border-primary/40"
            >
              <span className="min-w-0">
                <span className="block text-xs font-light tracking-widest text-muted-foreground uppercase">
                  Next case study
                </span>
                <span className="mt-2 block truncate text-3xl font-light">{next.title}</span>
              </span>
              <span
                aria-hidden="true"
                className="shrink-0 text-2xl text-primary transition-transform duration-300 group-hover:translate-x-2"
              >
                →
              </span>
            </Link>
          </Reveal>
        </div>
      </section>
    </article>
  );
}

function Meta({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="min-w-0">
      <h3 className="text-xs font-light tracking-widest text-primary uppercase">{title}</h3>
      <ul className="mt-3 space-y-1.5">
        {items.map((i) => (
          <li key={i} className="text-sm font-light text-muted-foreground">
            {i}
          </li>
        ))}
      </ul>
    </div>
  );
}