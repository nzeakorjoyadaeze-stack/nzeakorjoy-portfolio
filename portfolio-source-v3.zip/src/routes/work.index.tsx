import { createFileRoute, Link } from "@tanstack/react-router";
import { Reveal } from "@/components/site/Reveal";
import { projects } from "@/data/projects";

const TITLE = "Work — Case Studies by Adaeze Joy Nzeakor";
const DESCRIPTION =
  "Three in-depth digital media case studies, including a live client website for a Nigerian chartered accounting firm, a student wayfinding product, and a nonprofit brand and platform redesign.";

export const Route = createFileRoute("/work/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
    ],
  }),
  component: WorkIndex,
});

function WorkIndex() {
  return (
    <div className="px-4 pb-28 pt-36 sm:px-6 lg:pt-44">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <p className="text-xs font-light tracking-widest text-primary uppercase">Selected work</p>
          <h1 className="text-balance-tight mt-6 max-w-3xl text-5xl font-extralight leading-[1.02] sm:text-6xl">
            Three projects, documented the way I actually work.
          </h1>
          <p className="mt-6 max-w-2xl text-lg font-light text-muted-foreground">
            Each case study runs the full arc — the real-world challenge, the research that reframed it,
            the design process and its dead ends, how it was built, the final experience, and an honest
            reflection.
          </p>
        </Reveal>

        <div className="mt-20 grid gap-8 lg:grid-cols-3">
          {projects.map((p, i) => (
            <Reveal key={p.slug} delay={i * 0.08}>
              <Link
                to="/work/$slug"
                params={{ slug: p.slug }}
                className="group glass flex h-full flex-col overflow-hidden rounded-3xl transition-all duration-500 hover:border-primary/40 hover:-translate-y-1"
              >
                <div className="aspect-4/3 overflow-hidden">
                  <img
                    src={p.cover}
                    alt={p.coverAlt}
                    loading="lazy"
                    width={1600}
                    height={1000}
                    className="size-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-105"
                  />
                </div>
                <div className="flex flex-1 flex-col gap-4 p-7">
                  <p className="text-xs font-light tracking-widest text-primary uppercase">{p.category}</p>
                  <h2 className="text-2xl font-light tracking-tight">{p.title}</h2>
                  <p className="flex-1 text-sm font-light leading-relaxed text-muted-foreground">
                    {p.summary}
                  </p>
                  <span className="text-sm font-medium">
                    Read case study{" "}
                    <span aria-hidden="true" className="inline-block transition-transform duration-300 group-hover:translate-x-1">
                      →
                    </span>
                  </span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.1}>
          <section
            aria-labelledby="also-live-heading"
            className="glass mt-16 grid gap-6 rounded-3xl p-8 sm:p-10 md:grid-cols-[minmax(0,1fr)_auto] md:items-center"
          >
            <div className="min-w-0">
              <p className="text-xs font-light tracking-widest text-primary uppercase">
                Shipped work
              </p>
              <h2 id="also-live-heading" className="mt-3 text-2xl font-light tracking-tight">
                Prefer to check the live product?
              </h2>
              <p className="mt-3 max-w-xl text-sm font-light leading-relaxed text-muted-foreground">
                The Saidu B. Samaila &amp; Co. case study is a real client project running in
                production. Every claim in it can be verified against the live site.
              </p>
            </div>
            <a
              href="https://www.sbsamailaaccountants.com"
              target="_blank"
              rel="noreferrer noopener"
              className="group inline-flex items-center gap-3 justify-self-start rounded-full border border-border px-6 py-3 text-sm font-medium transition-all duration-300 hover:border-primary/50 hover:gap-5 hover:text-primary"
            >
              Visit the live site
              <span aria-hidden="true" className="transition-transform duration-300 group-hover:translate-x-1">
                ↗
              </span>
            </a>
          </section>
        </Reveal>
      </div>
    </div>
  );
}