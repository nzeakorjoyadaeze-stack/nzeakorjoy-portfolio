import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { HeroBackground } from "@/components/site/HeroBackground";
import { Reveal } from "@/components/site/Reveal";
import { projects } from "@/data/projects";

const TITLE = "Adaeze Joy Nzeakor — Digital Media Designer & Creative Strategist";
const DESCRIPTION =
  "Portfolio of Adaeze Joy Nzeakor: digital media designer, creative strategist and digital experience creator with a communications background. Three in-depth case studies.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
    ],
  }),
  component: Index,
});

const capabilities = [
  "UX & Interaction Design",
  "Creative Strategy",
  "Brand & Identity",
  "User Research",
  "Immersive Media",
  "Content Strategy",
  "Prototyping",
  "Design Systems",
];

function Index() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Person",
            name: "Adaeze Joy Nzeakor",
            jobTitle: "Digital Media Designer & Creative Strategist",
            email: "nzeakorjoyadaeze@gmail.com",
            sameAs: ["https://www.linkedin.com/in/nzeakorjoy"],
          }),
        }}
      />

      <section className="grain relative flex min-h-[100svh] items-center overflow-hidden px-4 pb-24 pt-36 sm:px-6">
        <HeroBackground />
        <div className="relative mx-auto w-full max-w-6xl">
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="glass inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-light tracking-widest text-muted-foreground uppercase"
          >
            <span className="size-1.5 rounded-full bg-primary" />
            Remote · Portfolio 2026
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 28 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.08, ease: [0.22, 1, 0.36, 1] }}
            className="text-balance-tight mt-8 text-5xl font-extralight leading-[0.95] sm:text-7xl lg:text-8xl"
          >
            Adaeze Joy
            <br />
            <span className="font-medium text-primary">Nzeakor</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            className="mt-8 max-w-2xl text-lg font-light leading-relaxed text-muted-foreground sm:text-xl"
          >
            Digital media designer, creative strategist, and digital experience creator. I come from
            communications, which means I start with the message and the human before the interface —
            then build the product, brand, or immersive experience that carries it.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.32, ease: [0.22, 1, 0.36, 1] }}
            className="mt-12"
          >
            <Link
              to="/work"
              className="group inline-flex items-center gap-3 rounded-full bg-primary px-8 py-4 text-base font-medium text-primary-foreground transition-all duration-300 hover:gap-5 hover:shadow-[var(--shadow-glow)]"
            >
              View My Work
              <span aria-hidden="true" className="transition-transform duration-300 group-hover:translate-x-1">
                →
              </span>
            </Link>
          </motion.div>
        </div>
      </section>

      <section className="border-y border-border px-4 py-6 sm:px-6" aria-label="Capabilities">
        <div className="mx-auto flex max-w-6xl flex-wrap gap-x-8 gap-y-3 text-xs font-light tracking-widest text-muted-foreground uppercase">
          {capabilities.map((c) => (
            <span key={c} className="transition-colors hover:text-primary">
              {c}
            </span>
          ))}
        </div>
      </section>

      <section className="px-4 py-24 sm:px-6 lg:py-32" aria-labelledby="work-heading">
        <div className="mx-auto max-w-6xl">
          <Reveal>
            <div className="grid gap-4 md:grid-cols-[minmax(0,1fr)_auto] md:items-end">
              <h2 id="work-heading" className="text-balance-tight text-4xl font-extralight sm:text-5xl">
                Selected <span className="text-primary">case studies</span>
              </h2>
              <p className="max-w-sm text-sm font-light text-muted-foreground">
                Three projects, documented end to end — challenge, research, process, build, outcome,
                and what I would do differently.
              </p>
            </div>
          </Reveal>

          <div className="mt-16 space-y-8">
            {projects.map((p, i) => (
              <Reveal key={p.slug} delay={i * 0.06}>
                <Link
                  to="/work/$slug"
                  params={{ slug: p.slug }}
                  className="group glass block overflow-hidden rounded-3xl transition-all duration-500 hover:border-primary/40"
                >
                  <div className="grid gap-0 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)]">
                    <div className="relative aspect-16/10 overflow-hidden">
                      <img
                        src={p.cover}
                        alt={p.coverAlt}
                        loading="lazy"
                        width={1600}
                        height={1000}
                        className="size-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-105"
                      />
                    </div>
                    <div className="flex flex-col justify-between gap-8 p-7 sm:p-10">
                      <div className="min-w-0">
                        <p className="text-xs font-light tracking-widest text-primary uppercase">
                          {p.category} · {p.year}
                        </p>
                        {p.kind && (
                          <p className="mt-3 inline-flex items-center gap-2 rounded-full border border-border px-3 py-1 text-[0.7rem] font-light tracking-widest text-muted-foreground uppercase">
                            <span aria-hidden="true" className="size-1 rounded-full bg-primary" />
                            {p.kind}
                          </p>
                        )}
                        <h3 className="mt-4 text-3xl font-light tracking-tight sm:text-4xl">{p.title}</h3>
                        <p className="mt-3 text-base font-light text-muted-foreground">{p.subtitle}</p>
                      </div>
                      <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm font-light">
                        {p.outcomes.slice(0, 2).map((o) => (
                          <span key={o.label} className="text-muted-foreground">
                            <span className="text-primary">{o.value}</span> {o.label}
                          </span>
                        ))}
                      </div>
                      <span className="inline-flex items-center gap-2 text-sm font-medium text-foreground">
                        Read the case study
                        <span
                          aria-hidden="true"
                          className="transition-transform duration-300 group-hover:translate-x-1"
                        >
                          →
                        </span>
                      </span>
                    </div>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="px-4 pb-28 sm:px-6" aria-labelledby="approach-heading">
        <div className="mx-auto max-w-6xl">
          <Reveal>
            <div className="glass rounded-3xl p-8 sm:p-14">
              <h2 id="approach-heading" className="text-balance-tight text-3xl font-extralight sm:text-4xl">
                A communications mind, applied to digital experience.
              </h2>
              <div className="mt-10 grid gap-8 sm:grid-cols-3">
                {[
                  {
                    t: "Start with the message",
                    d: "Every interface is an argument. I define what it needs to say before deciding how it looks.",
                  },
                  {
                    t: "Design the structure",
                    d: "Information architecture is where most experience problems are solved — or created.",
                  },
                  {
                    t: "Build and measure",
                    d: "Prototypes, real users, and evidence. Craft matters, but proof is what makes it design.",
                  },
                ].map((c) => (
                  <div key={c.t}>
                    <h3 className="text-lg font-medium text-primary">{c.t}</h3>
                    <p className="mt-2 text-sm font-light leading-relaxed text-muted-foreground">{c.d}</p>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
