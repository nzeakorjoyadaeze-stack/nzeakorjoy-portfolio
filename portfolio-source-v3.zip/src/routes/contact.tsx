import { createFileRoute } from "@tanstack/react-router";
import { Reveal } from "@/components/site/Reveal";

const TITLE = "Contact — Adaeze Joy Nzeakor";
const DESCRIPTION =
  "Get in touch with Adaeze Joy Nzeakor, digital media designer and creative strategist working remotely.";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
    ],
  }),
  component: Contact,
});

const channels = [
  {
    label: "Email",
    value: "nzeakorjoyadaeze@gmail.com",
    href: "mailto:nzeakorjoyadaeze@gmail.com",
    note: "Best for project enquiries, collaborations, and applications.",
  },
  {
    label: "LinkedIn",
    value: "in/nzeakorjoy",
    href: "https://www.linkedin.com/in/nzeakorjoy",
    note: "Full professional background and current activity.",
  },
  {
    label: "Location",
    value: "Remote",
    href: null,
    note: "Working remotely and available across time zones.",
  },
];

function Contact() {
  return (
    <div className="px-4 pb-28 pt-36 sm:px-6 lg:pt-44">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <p className="text-xs font-light tracking-widest text-primary uppercase">Contact</p>
          <h1 className="text-balance-tight mt-6 max-w-3xl text-5xl font-extralight leading-[1.02] sm:text-6xl">
            Let's start a <span className="text-primary">conversation</span>.
          </h1>
          <p className="mt-6 max-w-2xl text-lg font-light text-muted-foreground">
            I'm open to design collaborations, research partnerships, freelance work, and conversations
            with faculty and students in digital media. The fastest way to reach me is email.
          </p>
        </Reveal>

        <div className="mt-16 grid gap-5 md:grid-cols-3">
          {channels.map((c, i) => (
            <Reveal key={c.label} delay={i * 0.06}>
              <div className="glass h-full rounded-3xl p-8 transition-all duration-500 hover:border-primary/40 hover:-translate-y-1">
                <h2 className="text-xs font-light tracking-widest text-primary uppercase">{c.label}</h2>
                {c.href ? (
                  <a
                    href={c.href}
                    target={c.href.startsWith("http") ? "_blank" : undefined}
                    rel="noreferrer noopener"
                    className="mt-4 block break-words text-xl font-light transition-colors hover:text-primary"
                  >
                    {c.value}
                  </a>
                ) : (
                  <p className="mt-4 text-xl font-light">{c.value}</p>
                )}
                <p className="mt-3 text-sm font-light leading-relaxed text-muted-foreground">{c.note}</p>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.12}>
          <div className="glass mt-8 grid gap-8 rounded-3xl p-10 sm:p-14 md:grid-cols-[minmax(0,1fr)_auto] md:items-center">
            <div className="min-w-0">
              <h2 className="text-balance-tight text-3xl font-extralight sm:text-4xl">
                Let's talk about the work
              </h2>
              <p className="mt-4 max-w-xl text-base font-light leading-relaxed text-muted-foreground">
                If you're reviewing this portfolio and would like additional material — full research
                documentation, prototype files, or references — I'm glad to share it.
              </p>
            </div>
            <a
              href="mailto:nzeakorjoyadaeze@gmail.com"
              className="group inline-flex items-center gap-3 justify-self-start rounded-full bg-primary px-8 py-4 text-base font-medium text-primary-foreground transition-all duration-300 hover:gap-5 hover:shadow-[var(--shadow-glow)]"
            >
              Email me
              <span aria-hidden="true" className="transition-transform duration-300 group-hover:translate-x-1">
                →
              </span>
            </a>
          </div>
        </Reveal>
      </div>
    </div>
  );
}