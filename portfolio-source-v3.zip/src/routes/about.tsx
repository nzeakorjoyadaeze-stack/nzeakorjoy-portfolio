import { createFileRoute, Link } from "@tanstack/react-router";
import { Reveal } from "@/components/site/Reveal";

const TITLE = "About — Adaeze Joy Nzeakor, Digital Media Designer";
const DESCRIPTION =
  "From communications to digital innovation: my approach to UX, interaction design, branding, emerging technologies, and entrepreneurial problem-solving.";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
    ],
  }),
  component: About,
});

const pillars = [
  {
    title: "Communications foundation",
    body: "My training is in how meaning travels — audience, framing, channel, and credibility. Before I open a design file I know who is being spoken to, what they already believe, and what needs to change. That discipline is the reason my design decisions can be defended rather than only admired.",
  },
  {
    title: "Passion for digital innovation",
    body: "I am drawn to the point where a new capability becomes a new kind of experience. I follow developments in AR, generative tooling, and spatial interfaces closely — not as novelty, but as material. The question that interests me is always the same: what does this let a person do that they could not do before?",
  },
  {
    title: "UX, interaction, branding",
    body: "I work across the whole stack of experience. Information architecture and interaction detail on one side, identity and voice on the other. Treating them as one system is what makes a product feel coherent instead of assembled.",
  },
  {
    title: "Emerging technologies",
    body: "Immersive and AI-assisted media are reshaping how stories are told and how institutions reach people. I prototype with them early and evaluate them honestly, keeping the human constraint — attention, fatigue, trust — at the centre of the judgement.",
  },
  {
    title: "Entrepreneurial mindset",
    body: "I have built projects with no budget, no team, and no brief, and shipped them anyway. I am comfortable defining scope, finding collaborators, running the process, and being accountable for the outcome rather than the deliverable.",
  },
  {
    title: "Problem-solving approach",
    body: "Reframe first, then design. Most of my best work came from discovering that the stated problem was not the real one. I research to find the actual constraint, structure the solution around it, prototype fast, and let evidence decide.",
  },
];

function About() {
  return (
    <div className="px-4 pb-28 pt-36 sm:px-6 lg:pt-44">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <p className="text-xs font-light tracking-widest text-primary uppercase">About</p>
          <h1 className="text-balance-tight mt-6 max-w-4xl text-5xl font-extralight leading-[1.02] sm:text-6xl">
            I design digital experiences the way a communicator does — message first, interface second.
          </h1>
        </Reveal>

        <Reveal delay={0.08}>
          <div className="mt-12 grid gap-8 lg:grid-cols-2">
            <p className="text-lg font-light leading-relaxed text-muted-foreground">
              I am Adaeze Joy Nzeakor, a digital media designer and creative strategist working remotely.
              My background is in communications, where I learned that the hardest part of any project is
              rarely the making — it is deciding what deserves to be said, to whom, and in what order.
            </p>
            <p className="text-lg font-light leading-relaxed text-muted-foreground">
              That foundation now sits underneath everything I build: products, brand systems, and
              immersive experiences. I am continuing to deepen the technical and research side of that
              practice, and to work at the scale where design, technology, and storytelling meet.
            </p>
          </div>
        </Reveal>

        <div className="mt-20 grid gap-6 md:grid-cols-2">
          {pillars.map((p, i) => (
            <Reveal key={p.title} delay={i * 0.05}>
              <div className="glass h-full rounded-3xl p-8 transition-all duration-500 hover:border-primary/40 hover:-translate-y-1">
                <h2 className="text-xl font-medium text-primary">{p.title}</h2>
                <p className="mt-4 text-base font-light leading-relaxed text-muted-foreground">{p.body}</p>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.1}>
          <div className="mt-20 grid gap-10 border-t border-border pt-14 md:grid-cols-3">
            <Column
              title="Design"
              items={["UX & UI design", "Interaction design", "Design systems", "Prototyping", "Motion"]}
            />
            <Column
              title="Strategy"
              items={["Brand strategy", "Content strategy", "User research", "Workshop facilitation", "Positioning"]}
            />
            <Column
              title="Making"
              items={["Figma", "Webflow", "After Effects", "Blender", "8th Wall", "React basics"]}
            />
          </div>
        </Reveal>

        <Reveal delay={0.12}>
          <div className="glass mt-20 rounded-3xl p-10 text-center sm:p-16">
            <h2 className="text-balance-tight text-3xl font-extralight sm:text-4xl">
              Let's talk about what we could build.
            </h2>
            <Link
              to="/contact"
              className="group mt-8 inline-flex items-center gap-3 rounded-full bg-primary px-8 py-4 text-base font-medium text-primary-foreground transition-all duration-300 hover:gap-5 hover:shadow-[var(--shadow-glow)]"
            >
              Get in touch
              <span aria-hidden="true" className="transition-transform duration-300 group-hover:translate-x-1">
                →
              </span>
            </Link>
          </div>
        </Reveal>
      </div>
    </div>
  );
}

function Column({ title, items }: { title: string; items: string[] }) {
  return (
    <div>
      <h2 className="text-xs font-light tracking-widest text-primary uppercase">{title}</h2>
      <ul className="mt-5 space-y-2">
        {items.map((i) => (
          <li key={i} className="text-base font-light text-muted-foreground">
            {i}
          </li>
        ))}
      </ul>
    </div>
  );
}