import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="border-t border-border px-4 py-14 sm:px-6">
      <div className="mx-auto grid max-w-6xl gap-10 md:grid-cols-[minmax(0,1.4fr)_auto]">
        <div className="min-w-0">
          <p className="text-2xl font-light tracking-tight sm:text-3xl">
            Designing <span className="text-primary">digital experiences</span> where strategy,
            storytelling, and technology meet.
          </p>
          <p className="mt-4 max-w-md text-sm font-light text-muted-foreground">
            Open to collaboration, research partnerships, and conversations about digital experience.
          </p>
        </div>
        <div className="flex flex-col gap-3 text-sm font-light">
          <Link to="/work" className="text-muted-foreground transition-colors hover:text-primary">
            Selected work
          </Link>
          <Link to="/about" className="text-muted-foreground transition-colors hover:text-primary">
            About
          </Link>
          <Link to="/contact" className="text-muted-foreground transition-colors hover:text-primary">
            Contact
          </Link>
          <a
            href="https://www.linkedin.com/in/nzeakorjoy"
            target="_blank"
            rel="noreferrer noopener"
            className="text-muted-foreground transition-colors hover:text-primary"
          >
            LinkedIn
          </a>
          <a
            href="https://www.sbsamailaaccountants.com"
            target="_blank"
            rel="noreferrer noopener"
            className="text-muted-foreground transition-colors hover:text-primary"
          >
            Live site: S.B. Samaila &amp; Co. ↗
          </a>
        </div>
      </div>
      <div className="mx-auto mt-12 flex max-w-6xl flex-wrap items-center justify-between gap-3 border-t border-border pt-6 text-xs font-light text-muted-foreground">
        <span>© {new Date().getFullYear()} Adaeze Joy Nzeakor</span>
        <span>Remote</span>
      </div>
    </footer>
  );
}