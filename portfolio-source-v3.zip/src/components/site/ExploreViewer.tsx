import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import type { Project } from "@/data/projects";
import { analyticsEvents, trackEvent } from "@/lib/analytics";

type ViewerItem = {
  id: string;
  label: string;
  type: string;
  description: string;
  href?: string;
  kind: "embed" | "video" | "compare" | "gallery";
};

function buildItems(project: Project): ViewerItem[] {
  const items: ViewerItem[] = [
    {
      id: "prototype",
      label: project.prototype.label,
      type: "Prototype",
      description: `Walk through the interactive flows, screens, and interaction details behind ${project.title}.`,
      href: project.prototype.href,
      kind: "embed",
    },
    ...project.explore.map((e, i) => ({
      id: `explore-${i}`,
      label: e.label,
      type: e.type,
      description: e.description,
      href: e.href,
      kind: /video/i.test(e.type) ? ("video" as const) : ("embed" as const),
    })),
    {
      id: "compare",
      label: "Before and after",
      type: "Comparison",
      description: "Drag the handle to compare the prior experience with the redesigned one, with measured results.",
      kind: "compare",
    },
    {
      id: "gallery",
      label: "Full-size visuals",
      type: "Gallery",
      description: "Every artefact at full size — screens, diagrams, and process work you can inspect closely.",
      kind: "gallery",
    },
  ];
  return items;
}

export function ExploreViewer({ project }: { project: Project }) {
  const items = buildItems(project);
  const [openId, setOpenId] = useState<string | null>(null);
  const active = items.find((i) => i.id === openId) ?? null;
  const openedAt = useRef<number>(0);

  const openItem = (item: ViewerItem) => {
    openedAt.current = Date.now();
    setOpenId(item.id);
    trackEvent(analyticsEvents.exploreOpen, {
      project: project.slug,
      item_id: item.id,
      item_label: item.label,
      item_type: item.type,
      item_kind: item.kind,
    });
  };

  const closeViewer = (method: "backdrop" | "button" | "escape") => {
    if (active) {
      trackEvent(analyticsEvents.exploreClose, {
        project: project.slug,
        item_id: active.id,
        item_kind: active.kind,
        method,
        seconds_open: Math.round((Date.now() - openedAt.current) / 1000),
      });
    }
    setOpenId(null);
  };

  useEffect(() => {
    if (!active) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeViewer("escape");
    };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [active]);

  return (
    <>
      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        {items.map((e) => (
          <button
            key={e.id}
            type="button"
            onClick={() => openItem(e)}
            className="glass group flex h-full flex-col rounded-2xl p-6 text-left transition-colors duration-300 hover:border-primary/40"
          >
            <span className="text-xs font-light tracking-widest text-primary uppercase">{e.type}</span>
            <span className="mt-3 flex items-center gap-2 text-lg font-light">
              {e.label}
              <span aria-hidden="true" className="text-primary transition-transform duration-300 group-hover:translate-x-1">
                →
              </span>
            </span>
            <span className="mt-2 text-sm font-light leading-relaxed text-muted-foreground">
              {e.description}
            </span>
          </button>
        ))}
      </div>

      <AnimatePresence>
        {active && (
          <motion.div
            className="fixed inset-0 z-100 flex items-end justify-center bg-background/85 p-0 backdrop-blur-xl sm:items-center sm:p-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            role="dialog"
            aria-modal="true"
            aria-label={active.label}
            onClick={() => closeViewer("backdrop")}
          >
            <motion.div
              initial={{ opacity: 0, y: 24, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 24, scale: 0.98 }}
              transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
              onClick={(ev) => ev.stopPropagation()}
              className="glass flex max-h-[92vh] w-full max-w-5xl flex-col overflow-hidden rounded-t-3xl sm:rounded-3xl"
            >
              <div className="flex shrink-0 items-start justify-between gap-6 border-b border-border px-6 py-5 sm:px-8">
                <div className="min-w-0">
                  <p className="text-xs font-light tracking-widest text-primary uppercase">{active.type}</p>
                  <h3 className="mt-1 truncate text-xl font-light">{active.label}</h3>
                </div>
                <div className="flex shrink-0 items-center gap-3">
                  {active.href && (
                    <a
                      href={active.href}
                      target="_blank"
                      rel="noreferrer noopener"
                      onClick={() =>
                        trackEvent(analyticsEvents.mediaClick, {
                          project: project.slug,
                          item_id: active.id,
                          item_label: active.label,
                          item_type: active.type,
                          destination: active.href ?? "",
                          location: "viewer_header",
                        })
                      }
                      className="hidden rounded-full border border-border px-4 py-2 text-xs font-light transition-colors hover:border-primary/50 hover:text-primary sm:inline-block"
                    >
                      Open in new tab ↗
                    </a>
                  )}
                  <button
                    type="button"
                    onClick={() => closeViewer("button")}
                    aria-label="Close viewer"
                    className="rounded-full border border-border px-3 py-2 text-sm leading-none transition-colors hover:border-primary/50 hover:text-primary"
                  >
                    ✕
                  </button>
                </div>
              </div>

              <div className="min-h-0 flex-1 overflow-y-auto">
                <ViewerBody item={active} project={project} />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

function ViewerBody({ item, project }: { item: ViewerItem; project: Project }) {
  if (item.kind === "compare") {
    return (
      <div className="p-6 sm:p-8">
        <CompareSlider
          project={project}
          before={project.gallery[0]?.src ?? project.cover}
          after={project.cover}
          beforeAlt={`Before — ${project.gallery[0]?.alt ?? project.coverAlt}`}
          afterAlt={`After — ${project.coverAlt}`}
        />
        <div className="mt-8 overflow-hidden rounded-2xl border border-border">
          <table className="w-full text-left">
            <caption className="sr-only">Measured before and after results</caption>
            <thead>
              <tr className="border-b border-border">
                <th scope="col" className="px-5 py-3 text-xs font-light tracking-widest text-muted-foreground uppercase">Measure</th>
                <th scope="col" className="px-5 py-3 text-xs font-light tracking-widest text-muted-foreground uppercase">Before</th>
                <th scope="col" className="px-5 py-3 text-xs font-light tracking-widest text-primary uppercase">After</th>
              </tr>
            </thead>
            <tbody>
              {project.impact.comparisons.map((c) => (
                <tr key={c.metric} className="border-b border-border last:border-0">
                  <th scope="row" className="px-5 py-4 text-sm font-light text-muted-foreground">{c.metric}</th>
                  <td className="px-5 py-4 text-sm font-light text-muted-foreground">{c.before}</td>
                  <td className="px-5 py-4 text-sm font-medium text-primary">{c.after}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  if (item.kind === "gallery") {
    return (
      <div className="grid gap-4 p-6 sm:grid-cols-2 sm:p-8">
        {project.gallery.map((g) => (
          <figure key={g.caption} className="overflow-hidden rounded-2xl border border-border">
            <img src={g.src} alt={g.alt} loading="lazy" className="w-full object-cover" />
            <figcaption className="px-4 py-3 text-xs font-light tracking-widest text-muted-foreground uppercase">
              {g.caption}
            </figcaption>
          </figure>
        ))}
      </div>
    );
  }

  return <EmbedFrame item={item} />;
}

function EmbedFrame({ item }: { item: ViewerItem }) {
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setFailed(false);
    const t = setTimeout(() => setFailed(true), 4000);
    return () => clearTimeout(t);
  }, [item.id]);

  return (
    <div className="p-6 sm:p-8">
      <div className="relative aspect-16/10 w-full overflow-hidden rounded-2xl border border-border bg-secondary/30">
        {item.href && (
          <iframe
            key={item.id}
            src={item.href}
            title={item.label}
            className="absolute inset-0 h-full w-full"
            allow="fullscreen; clipboard-write"
            onLoad={() => setFailed(false)}
          />
        )}
        {failed && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-background/90 p-8 text-center backdrop-blur-sm">
            <p className="max-w-sm text-sm font-light leading-relaxed text-muted-foreground">
              This resource blocks embedding. Open it in a new tab to explore the full artefact.
            </p>
            <a
              href={item.href}
              target="_blank"
              rel="noreferrer noopener"
              onClick={() =>
                trackEvent(analyticsEvents.mediaClick, {
                  item_id: item.id,
                  item_label: item.label,
                  item_type: item.type,
                  destination: item.href ?? "",
                  location: "embed_fallback",
                })
              }
              className="rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition-all hover:shadow-[var(--shadow-glow)]"
            >
              Open {item.label} ↗
            </a>
          </div>
        )}
      </div>
      <p className="mt-4 text-sm font-light leading-relaxed text-muted-foreground">{item.description}</p>
    </div>
  );
}

function CompareSlider({
  project,
  before,
  after,
  beforeAlt,
  afterAlt,
}: {
  project: Project;
  before: string;
  after: string;
  beforeAlt: string;
  afterAlt: string;
}) {
  const [value, setValue] = useState(50);
  const interacted = useRef(false);
  const lastSent = useRef(0);

  const handleChange = (next: number) => {
    setValue(next);
    const now = Date.now();
    if (!interacted.current) {
      interacted.current = true;
      trackEvent(analyticsEvents.compareUse, {
        project: project.slug,
        interaction: "first_drag",
        position: next,
      });
      lastSent.current = now;
      return;
    }
    // throttle continuous drag events
    if (now - lastSent.current > 1200) {
      lastSent.current = now;
      trackEvent(analyticsEvents.compareUse, {
        project: project.slug,
        interaction: "drag",
        position: next,
      });
    }
  };
  return (
    <div>
      <div className="relative aspect-16/10 w-full select-none overflow-hidden rounded-2xl border border-border">
        <img src={before} alt={beforeAlt} className="absolute inset-0 h-full w-full object-cover grayscale" />
        <div className="absolute inset-0 overflow-hidden" style={{ width: `${value}%` }}>
          <img
            src={after}
            alt={afterAlt}
            className="absolute inset-0 h-full w-full object-cover"
            style={{ width: "100%" }}
          />
        </div>
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-y-0 w-px bg-primary"
          style={{ left: `${value}%` }}
        />
        <span className="pointer-events-none absolute left-4 top-4 rounded-full bg-background/70 px-3 py-1 text-xs font-light tracking-widest uppercase backdrop-blur">
          After
        </span>
        <span className="pointer-events-none absolute right-4 top-4 rounded-full bg-background/70 px-3 py-1 text-xs font-light tracking-widest uppercase backdrop-blur">
          Before
        </span>
      </div>
      <label className="mt-4 block">
        <span className="text-xs font-light tracking-widest text-muted-foreground uppercase">
          Drag to compare
        </span>
        <input
          type="range"
          min={0}
          max={100}
          value={value}
          onChange={(e) => handleChange(Number(e.target.value))}
          aria-label="Compare before and after"
          className="mt-3 w-full accent-primary"
        />
      </label>
    </div>
  );
}