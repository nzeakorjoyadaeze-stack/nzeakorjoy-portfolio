import { useEffect, useRef } from "react";

/**
 * Animated 3D-inspired backdrop: layered depth orbs that parallax with the
 * pointer and drift slowly on their own. Pure CSS transforms, no WebGL.
 */
export function HeroBackground() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    let frame = 0;
    const onMove = (e: PointerEvent) => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const x = e.clientX / window.innerWidth - 0.5;
        const y = e.clientY / window.innerHeight - 0.5;
        el.style.setProperty("--px", String(x));
        el.style.setProperty("--py", String(y));
      });
    };

    window.addEventListener("pointermove", onMove);
    return () => {
      window.removeEventListener("pointermove", onMove);
      cancelAnimationFrame(frame);
    };
  }, []);

  return (
    <div
      ref={ref}
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 overflow-hidden [--px:0] [--py:0]"
      style={{ perspective: "1000px" }}
    >
      <div
        className="absolute -left-[10%] top-[5%] h-[42rem] w-[42rem] rounded-full opacity-40 blur-[120px] transition-transform duration-700 ease-out"
        style={{
          background:
            "radial-gradient(circle at 30% 30%, var(--primary), transparent 65%)",
          transform:
            "translate3d(calc(var(--px) * 60px), calc(var(--py) * 60px), 0)",
        }}
      />
      <div
        className="absolute -right-[15%] top-[25%] h-[36rem] w-[36rem] rounded-full opacity-25 blur-[140px] transition-transform duration-1000 ease-out"
        style={{
          background:
            "radial-gradient(circle at 60% 40%, oklch(0.7 0.12 60), transparent 70%)",
          transform:
            "translate3d(calc(var(--px) * -90px), calc(var(--py) * -70px), 0)",
        }}
      />
      <div
        className="absolute left-1/2 top-1/3 h-[30rem] w-[30rem] -translate-x-1/2 rounded-full opacity-15 blur-[100px] transition-transform duration-500 ease-out"
        style={{
          background: "radial-gradient(circle, oklch(1 0 0), transparent 65%)",
          transform:
            "translate3d(calc(-50% + var(--px) * 30px), calc(var(--py) * 40px), 0)",
        }}
      />
      {/* wireframe grid plane for depth */}
      <div
        className="absolute inset-x-0 bottom-0 h-[55%] opacity-[0.13] transition-transform duration-700 ease-out"
        style={{
          backgroundImage:
            "linear-gradient(to right, oklch(1 0 0 / 40%) 1px, transparent 1px), linear-gradient(to bottom, oklch(1 0 0 / 40%) 1px, transparent 1px)",
          backgroundSize: "70px 70px",
          transform:
            "rotateX(72deg) translate3d(calc(var(--px) * -40px), 0, 0)",
          transformOrigin: "bottom center",
          maskImage: "linear-gradient(to top, black, transparent 80%)",
        }}
      />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_25%,var(--background)_88%)]" />
    </div>
  );
}